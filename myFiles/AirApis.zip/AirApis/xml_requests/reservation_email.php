<?php

/**
 * @Author: Umar Hayat
 * @Date:   2019-09-17 11:33:52
 * @Last Modified by:   Muhammad Umar Hayat
 * @Last Modified time: 2019-11-27 18:23:56
 */
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Air Ticket Reservation</title>
</head>

<body>
<table width="50%" cellpadding="5" style="font-family:Arial, Helvetica, sans-serif;">
  <tr>
    <td style="border-bottom:solid 1px #C1C1C1;" colspan="2">
    	<table cellpadding="0" cellspacing="0" style="width:100%">
            <tr>
              <td style="float:left; width:50%;"><span style="font-size:14px; font-weight:bold; vertical-align: super;"><?=self::$record['airline']?></span><img style="width:10%; padding: 0px 0 0 3px;" src="https://goprivate.wspan.com/sharedservices/images/airlineimages/logoAir<?=self::$record['carrier']?>.gif" /></td>
              <td style="float:right; width:50%;"><img style="width:20%; padding: 0px 0 0 3px; float:right" src="https://bookme.pk/assets/images/Bookme-Logo.png" /></td>
            </tr>
      	</table>
    </td>
  </tr>
  <tr>
    <td colspan="2">
    	<table cellpadding="0" cellspacing="0" style="width:100%">
            <tr>
              <td style="float:left; width:50%;"><span style="font-size:12px; font-weight:bold; color:#757572">Hello Dear <?=self::$record['name']?>,</span></td>
              <td style="float:right; width:50%;"><span style="font-size:12px; color:#757572; float:right; font-weight:bold;">Issue Date: <?=(new Datetime(self::$record['created_at']))->format('F d, Y')?></span></td>
            </tr>
      	</table>
    </td>
  </tr>
  <tr>
    <td colspan="2">
    	<table cellpadding="0" cellspacing="0" style="width:100%; background-image:url(https://bookme.pk/assets/images/bg.jpg); height:100px; color:#fff; text-align:center;">
            <tr>
              <td style="float:left; width:100%; margin-top:15px;"><img style="width:7%;" src="https://bookme.pk/assets/images/air_line2.png" /></td>
          	</tr>
            <tr>
            	<td style="float:left; width:100%;"><span style="font-size:18px; color:#fff">Your Trip Reservation Confirmation</span></td>
            </tr>
      	</table>
    </td>
  </tr>
  <tr>
    <td style="border-bottom:solid 1px #C1C1C1;" colspan="2">
    	<table cellpadding="0" cellspacing="0" style="width:100%">
            <tr>
              <td style="width:100%; text-align:center;"><span style="font-size:14px; font-weight:600;">Record Locator: <b style="font-weight:800;"><?=self::$record['reservation_locator_code']?></b></span></td>
            </tr>
      	</table>
    </td>
  </tr>
  	<?php $pre_date = null; foreach(self::$airSegments as $air_segment): ?>
	  	<?php if($pre_date != $air_segment['departure_datetime']): $pre_date = $air_segment['departure_datetime']; ?>
		  <tr>
		    <td colspan="2">
		    	<table cellpadding="0" cellspacing="0" style="width:100%">
		            <tr>
		              <td style="width:100%;"><span style="font-size:16px; font-weight:600; color:#388fdb; vertical-align: super; margin-left: 11px;"><?=(new Datetime($air_segment['departure_datetime']))->format('l, F d, Y')?></span></td>
		            </tr>
		      	</table>
		    </td>
		  </tr>
		<?php endif; ?>
	  <tr>
	    <td colspan="2">
	    	<table cellpadding="0" cellspacing="0" style="width:100%">
	            <tr>
	              <td style="width:10%"></td>
	              <td style="width:25%;"><span style="font-size:14px; color:#757572"><?=$air_segment['travel_from']?><br /><b style="font-size:18px; font-weight:700"><?=(new Datetime($air_segment['departure_datetime']))->format('h:i')?></b> <b style="font-size:16px; font-weight:400;"><?=(new Datetime($air_segment['departure_datetime']))->format('a')?></b><br /><b style="font-size:14px; font-weight:400;"><?=Airport::getFullnameByCode($air_segment['travel_from'])?></b></span></td>
	              <td style="width:20%; float:left;"><img style="margin-top: 15px;" src="https://bookme.pk/assets/images/errow.png" /></td>
	              <td style="width:35%; float:left;"><span style="font-size:14px; color:#757572"><?=$air_segment['travel_to']?><br /><b style="font-size:18px; font-weight:700"><?=(new Datetime($air_segment['arrival_datetime']))->format('h:i')?></b> <b style="font-size:16px; font-weight:400;"><?=(new Datetime($air_segment['arrival_datetime']))->format('a')?></b><br /><b style="font-size:14px; font-weight:400;"><?=Airport::getFullnameByCode($air_segment['travel_to'])?></b></span></td>
	              <td style="width:25%;"><span style="font-size:12px; font-weight:bold; color:#757572">Seats: <?=self::getSeatsBySegment(self::$record['id'], $air_segment['id'])?><br />Class: <?=self::$record['class']?> (<?=$air_segment['class']?>)</span></td>
	            </tr>
	      	</table>
	    </td>
	  </tr>
	<?php endforeach; ?>
  <tr>
    <td colspan="2">
    	<table cellpadding="0" cellspacing="0" style="width:100%">
            <tr>
              <td style="float:left; width:100%;"><span style="font-size:10px; color:#757572"><i>*</i> Denotes Unassigned Seats.</span></td>
            </tr>
      	</table>
    </td>
  </tr>
</table>
</body>
</html>