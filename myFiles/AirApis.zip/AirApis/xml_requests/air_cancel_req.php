<?php
if(!defined('REQUEST_DIR'))
  die();
/**
 * @Author: Umar Hayat
 * @Date:   2019-10-11 21:29:10
 * @Last Modified by:   Umar Hayat
 * @Last Modified time: 2019-10-11 21:30:40
 */
?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:com="http://www.travelport.com/schema/common_v34_0" xmlns:univ="http://www.travelport.com/schema/universal_v34_0">   	
<soapenv:Header/>   
	<soapenv:Body>      
		<univ:UniversalRecordCancelReq AuthorizedBy="user" TargetBranch="<?=TP_TARGET_BRANCH?>" TraceId="trace" UniversalRecordLocatorCode="<?=$universal_locator_code?>" Version="1">         
			<com:BillingPointOfSaleInfo OriginApplication="UAPI"/>      
		</univ:UniversalRecordCancelReq>   
	</soapenv:Body>
</soapenv:Envelope>
