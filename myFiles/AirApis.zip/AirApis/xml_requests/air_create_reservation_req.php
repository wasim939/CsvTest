<?php
if(!defined('REQUEST_DIR'))
  die();
/**
 * @Author: Umar Hayat
 * @Date:   2019-07-31 17:31:08
 * @Last Modified by:   mailm
 * @Last Modified time: 2020-01-30 17:18:19
 */
?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:common_v42_0="http://www.travelport.com/schema/common_v42_0">   
	<soapenv:Header/>   
	<soapenv:Body>      
		<univ:AirCreateReservationReq xmlns:univ="http://www.travelport.com/schema/universal_v42_0" AuthorizedBy="user" RestrictWaitlist="true" RetainReservation="Both" TargetBranch="<?=TP_TARGET_BRANCH?>" TraceId="trace">         
			<com:BillingPointOfSaleInfo xmlns:com="http://www.travelport.com/schema/common_v42_0" OriginApplication="UAPI"/> 
			<?php foreach($travelerTypes as $i => $traveler_type): ?>            
			<?php
			    if($traveler_type == 'INF' && (!isset($dobs[$i]) || empty($dobs[$i])))
			    {
			        $dobs[$i] = (date('Y') - 1) . date('-m-d');
			    }
			?> 
			<com:BookingTraveler xmlns:com="http://www.travelport.com/schema/common_v42_0" <?=!empty($ages[$i]) ? 'Age="'. $ages[$i] .'"' : ''?> <?=!empty($dobs[$i]) ? 'DOB="'. $dobs[$i] .'"' : ''?> <?=!empty($genders[$i]) ? 'Gender="'. (strtolower($genders[$i]) == 'female' ? 'F' : 'M') .'"' : ''?> Key="<?=strtolower($traveler_type) . $i?>" TravelerType="<?=strtoupper($traveler_type)?>">            
				<com:BookingTravelerName First="<?=$firstnames[$i]?>" Last="<?=$lastnames[$i]?>" Prefix="<?=$prefixes[$i]?>"/>
				<?php if($traveler_type == 'ADT' && !isset($addressAdded)): ?>  
					<?php 
						$addressAdded = true;
					?>       
					<com:DeliveryInfo>               
						<com:ShippingAddress>
							<?php if(!empty($addressName)): ?>
								<com:AddressName><?=$addressName?></com:AddressName> 
							<?php endif; ?>
							<?php if(!empty($street)): ?>              
								<com:Street><?=$street?></com:Street>  
							<?php endif; ?>
							<?php if(!empty($city)): ?>                  
								<com:City><?=$city?></com:City>    
							<?php endif; ?>
							<?php if(!empty($state)): ?>                
								<com:State><?=$state?></com:State>  
							<?php endif; ?> 
							<?php if(!empty($postalCode)): ?>                 
								<com:PostalCode><?=$postalCode?></com:PostalCode> 
							<?php endif; ?>
							<?php if(!empty($country)): ?>                   
								<com:Country><?=$country?></com:Country>    
							<?php endif; ?>            
						</com:ShippingAddress>            
					</com:DeliveryInfo>            
					<com:PhoneNumber <?=!empty($areaCode) ? 'AreaCode="'. $areaCode .'"' : ''?> <?=!empty($countryCode) ? 'CountryCode="'. $countryCode .'"' : ''?> <?=!empty($location) ? 'Location="'. $location .'"' : ''?> Number="<?=$phoneNumber?>"/>            
					<com:Email EmailID="<?=$email?>" Type="Home"/>	   
					<?php if(isset($carrier, $passenger_country[$i], $passport_no[$i], $nationality[$i], $dobs[$i], $genders[$i], $passport_expiry[$i], $firstnames[$i], $lastnames[$i]) && !empty($passport_no[$i])): ?>
						<com:SSR Type="DOCS" FreeText="P/<?=$passenger_country[$i]?>/<?=$passport_no[$i]?>/<?=$nationality[$i]?>/<?=date('dMy', strtotime($dobs[$i]))?>/<?=strtolower($genders[$i]) == 'female' ? 'F' : 'M'?>/<?=date('dMy', strtotime($passport_expiry[$i]))?>/<?=$firstnames[$i]?>/<?=$lastnames[$i]?>" Carrier="<?=$carrier?>" />
					<?php endif; ?>
					<?php if(isset($cnic) && !empty($cnic) && !is_numeric($cnic)): ?>
						<com:NameRemark Category="CNIC">
							<com:RemarkData><?=$cnic?></com:RemarkData>
						</com:NameRemark>         
					<?php endif; ?>
					<com:Address>
						<?php if(!empty($addressName)): ?>
								<com:AddressName><?=$addressName?></com:AddressName> 
							<?php endif; ?>
							<?php if(!empty($street)): ?>              
								<com:Street><?=$street?></com:Street>  
							<?php endif; ?>
							<?php if(!empty($city)): ?>                  
								<com:City><?=$city?></com:City>    
							<?php endif; ?>
							<?php if(!empty($state)): ?>                
								<com:State><?=$state?></com:State>  
							<?php endif; ?> 
							<?php if(!empty($postalCode)): ?>                 
								<com:PostalCode><?=$postalCode?></com:PostalCode> 
							<?php endif; ?>
							<?php if(!empty($country)): ?>                   
								<com:Country><?=$country?></com:Country>    
							<?php endif; ?>          
					</com:Address>
				<?php elseif($traveler_type == 'ADT'): ?>
					<?php if(isset($carrier, $passenger_country[$i], $passport_no[$i], $nationality[$i], $dobs[$i], $genders[$i], $passport_expiry[$i], $firstnames[$i], $lastnames[$i]) && !empty($passport_no[$i])): ?>
						<com:SSR Type="DOCS" FreeText="P/<?=$passenger_country[$i]?>/<?=$passport_no[$i]?>/<?=$nationality[$i]?>/<?=date('dMy', strtotime($dobs[$i]))?>/<?=strtolower($genders[$i]) == 'female' ? 'F' : 'M'?>/<?=date('dMy', strtotime($passport_expiry[$i]))?>/<?=$firstnames[$i]?>/<?=$lastnames[$i]?>" Carrier="<?=$carrier?>" />
					<?php endif; ?>
				<?php elseif($traveler_type == 'CNN' || $traveler_type == 'INF'): ?>
					<?php if(isset($carrier, $passenger_country[$i], $passport_no[$i], $nationality[$i], $dobs[$i], $genders[$i], $passport_expiry[$i], $firstnames[$i], $lastnames[$i]) && !empty($passport_no[$i])): ?>
						<com:SSR Type="DOCS" FreeText="P/<?=$passenger_country[$i]?>/<?=$passport_no[$i]?>/<?=$nationality[$i]?>/<?=date('dMy', strtotime($dobs[$i]))?>/<?=strtolower($genders[$i]) == 'female' ? 'F' : 'M'?>/<?=date('dMy', strtotime($passport_expiry[$i]))?>/<?=$firstnames[$i]?>/<?=$lastnames[$i]?>" Carrier="<?=$carrier?>" />
					<?php endif; ?>
					<?php if($traveler_type == 'CNN'): ?>
						<com:NameRemark Category="AIR">
							<com:RemarkData>P-C05</com:RemarkData>
						</com:NameRemark>
					<?php endif; ?>
				<?php endif; ?>   
			</com:BookingTraveler>  
			<?php endforeach; ?>
			<com:ContinuityCheckOverride xmlns:com="http://www.travelport.com/schema/common_v42_0" />  
			<com:FormOfPayment xmlns:com="http://www.travelport.com/schema/common_v42_0" Key="jwt2mcK1Qp27I2xfpcCtAw==" Type="Cash"/>
			<air:AirPricingSolution xmlns:air="http://www.travelport.com/schema/air_v42_0" ApproximateBasePrice="<?=$aps_approx_base_price?>" ApproximateTotalPrice="<?=$aps_approx_total_price?>" BasePrice="<?=$aps_base_price?>" <?=isset($aps_eqv_price) ? 'EquivalentBasePrice="'. $aps_eqv_price .'"' : ''?> Key="<?=$aps_key?>" QuoteDate="<?=$aps_quote_date?>" Taxes="<?=$aps_taxes?>" TotalPrice="<?=$aps_total_price?>">
				<?php foreach($air_segments as $air_segment):
					echo $air_segment;
				endforeach; ?>
				<?php foreach($pricing_infos as $pricing_info):
					echo $pricing_info;
				endforeach; ?>
				<?php foreach($host_tokens as $host_token):
					echo $host_token;
				endforeach; ?>
				<?php 
					if(isset($optional_services) && count($optional_services) > 0):
				?>
				<air:OptionalServices>
			        <air:OptionalServicesTotal/>
			        <?php foreach($optional_services as $optional_service): 
			        	echo $optional_service;
			        endforeach; ?>
			    </air:OptionalServices>
			    <?php 
			    	endif;
			    ?>
			</air:AirPricingSolution>
			<com:ActionStatus xmlns:com="http://www.travelport.com/schema/common_v42_0" ProviderCode="<?=TP_GDS_CODE?>" TicketDate="<?=date('Y-m-d\TH:i:s', time() + 3600)?>" Type="TAW"/>
			<?php 
				$auto_seat_str 		= "";
				$specific_seat_str 	= "";
			?>
			<?php foreach($travelerTypes as $i => $traveler_type): ?>
				<?php foreach($specific_seats[$i] as $seat): 
						if(strcmp($seat['seat_code'], '*') == 0):
							$auto_seat_str .= '<air:AutoSeatAssignment xmlns:air="http://www.travelport.com/schema/air_v42_0" BookingTravelerRef="'. strtolower($traveler_type) . $i .'" SeatType="Any" SegmentRef="'. $seat['air_segment_ref_key'] .'"></air:AutoSeatAssignment>';
						else:
							$specific_seat_str .= '<air:SpecificSeatAssignment xmlns:air="http://www.travelport.com/schema/air_v42_0" BookingTravelerRef="'. strtolower($traveler_type) . $i .'" SeatId="'. $seat['seat_code'] .'" SegmentRef="'. $seat['air_segment_ref_key'] .'"></air:SpecificSeatAssignment>';
						endif;
					endforeach;?>
			<?php endforeach;?> <?=trim($auto_seat_str) ?><?=trim($specific_seat_str) ?>
		</univ:AirCreateReservationReq>   
	</soapenv:Body>
</soapenv:Envelope>
