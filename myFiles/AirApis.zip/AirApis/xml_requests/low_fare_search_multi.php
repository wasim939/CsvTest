<?php
if(!defined('REQUEST_DIR'))
  die();
/**
 * @Author: Umar Hayat
 * @Date:   2019-07-29 19:10:30
 * @Last Modified by:   Umar Hayat
 * @Last Modified time: 2019-10-04 01:37:24
 */
?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">   
 <soapenv:Header/>   
 <soapenv:Body>      
  <air:LowFareSearchReq xmlns:air="http://www.travelport.com/schema/air_v42_0" xmlns:com="http://www.travelport.com/schema/common_v42_0" AuthorizedBy="user" SolutionResult="true" TargetBranch="<?=TP_TARGET_BRANCH?>" TraceId="trace">         
   <com:BillingPointOfSaleInfo OriginApplication="UAPI"/> 

  <?php foreach($getDep as $i => $dep): ?>   
     <air:SearchAirLeg>            
      <air:SearchOrigin>               
       <com:Airport Code="<?=$dep?>"/>            
      </air:SearchOrigin>            
      <air:SearchDestination>               
       <com:Airport Code="<?=$getArr[$i]?>"/>            
      </air:SearchDestination>            
      <air:SearchDepTime PreferredTime="<?=$getDepDate[$i]?>"/>       
     </air:SearchAirLeg>
  <?php endforeach; ?>

   <air:AirSearchModifiers> 
    <air:PreferredProviders>               
     <com:Provider Code="<?=TP_GDS_CODE?>"/>            
    </air:PreferredProviders>    
	<air:PermittedCabins>
	 <com:CabinClass Type="<?=$getCabin?>"/>
	</air:PermittedCabins>     
   </air:AirSearchModifiers>
   <?php for($i = 0; $i < $getAdultNo; $i++): ?>
   		<com:SearchPassenger Code="ADT"/>
   <?php endfor;?>
   <?php if($getChildNo > 0): ?> 
   		<?php for($i = 0; $i < $getChildNo; $i++): ?>     
			<com:SearchPassenger Code="CNN"/>
		<?php endfor;?>
   <?php endif; ?>   
   <?php if($getInfantNo > 0): ?> 
   		<?php for($i = 0; $i < $getInfantNo; $i++): ?>     
   			<com:SearchPassenger Code="INF"/>
		<?php endfor;?>
   <?php endif; ?> 
  </air:LowFareSearchReq>   
 </soapenv:Body>
</soapenv:Envelope>