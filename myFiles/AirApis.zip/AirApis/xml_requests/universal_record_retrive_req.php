<?php
if(!defined('REQUEST_DIR'))
  die();
/**
 * @Author: Umar Hayat
 * @Date:   2019-07-31 17:31:08
 * @Last Modified by:   Umar Hayat
 * @Last Modified time: 2019-09-26 13:14:29
 */
?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:univ="http://www.travelport.com/schema/universal_v42_0" xmlns:com="http://www.travelport.com/schema/common_v42_0">
   <soapenv:Header>
      <univ:SupportedVersions/>
   </soapenv:Header>
   <soapenv:Body>
      <univ:UniversalRecordRetrieveReq TraceId="trace" AuthorizedBy="user" TargetBranch="<?=TP_TARGET_BRANCH?>"  RetrieveProviderReservationDetails="true" ViewOnlyInd="false">
         <com:BillingPointOfSaleInfo OriginApplication="UAPI"/>
         <univ:ProviderReservationInfo ProviderCode="<?=TP_GDS_CODE?>" ProviderLocatorCode="3QUYSB" />
      </univ:UniversalRecordRetrieveReq>
   </soapenv:Body>
</soapenv:Envelope>