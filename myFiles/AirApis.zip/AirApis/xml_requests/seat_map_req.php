<?php
if(!defined('REQUEST_DIR'))
  die();
/**
 * @Author: Umar Hayat
 * @Date:   2019-07-29 19:16:32
 * @Last Modified by:   Umar Hayat
 * @Last Modified time: 2019-08-21 18:21:58
 */
?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">   
 <soapenv:Header/>   
 <soapenv:Body>
	<SeatMapReq xmlns="http://www.travelport.com/schema/air_v42_0" TraceId="515be305-2464-482b-8f15-1fdf46fa68a1" AuthorizedBy="Travelport" TargetBranch="<?=TP_TARGET_BRANCH?>" ReturnSeatPricing="true" ReturnBrandingInfo="true">
	  <BillingPointOfSaleInfo xmlns="http://www.travelport.com/schema/common_v42_0" OriginApplication="uAPI" />
	  	<?php foreach($airSegmentRefKeys as $i =>  $airSegmentRefKey): ?>
			<AirSegment Key="<?=$airSegmentRefKey?>" HostTokenRef="<?=$hostTokenKeys[$i]?>" Equipment="<?=$planes[$i]?>" AvailabilityDisplayType="<?=$availabilityDisplayTypes[$i]?>" Group="<?=$groups[$i]?>" Carrier="<?=$carriers[$i]?>" FlightNumber="<?=$flightNumbers[$i]?>" Origin="<?=$origins[$i]?>" Destination="<?=$destinations[$i]?>" DepartureTime="<?=$departs[$i]?>" ArrivalTime="<?=$arrivals[$i]?>" FlightTime="<?=$flightTimes[$i]?>" Distance="<?=$distances[$i]?>" ProviderCode="<?=TP_GDS_CODE?>" ClassOfService="<?=$classes[$i]?>">
		    	<CodeshareInfo OperatingCarrier="<?=$carriers[$i]?>" />
		    </AirSegment>
		<?php endforeach;?>
		<?php foreach($hostTokenKeys as $i =>  $hostTokenKey): ?>
		  	<HostToken xmlns="http://www.travelport.com/schema/common_v42_0" Key="<?=$hostTokenKey?>"><?=$hostTokens[$i]?></HostToken>
		<?php endforeach;?>
		<?php for($i = 0; $i < $getAdultNo; $i++): ?>
			<SearchTraveler Code="ADT" Age="40" Key="adt<?=$i?>">
			    <Name xmlns="http://www.travelport.com/schema/common_v42_0" Prefix="Mr" First="John" Last="Smith" />
			</SearchTraveler>
		<?php endfor;?>
		<?php if($getChildNo > 0): ?> 
			<?php for($i = 0; $i < $getChildNo; $i++): ?>
				<SearchTraveler Code="CNN" Age="10" Key="cnn<?=$i?>">
				    <Name xmlns="http://www.travelport.com/schema/common_v42_0" Prefix="Mr" First="Michael" Last="Scott" />
				</SearchTraveler>
			<?php endfor;?>
		<?php endif; ?>   
		<?php if($getInfantNo > 0): ?> 
			<?php for($i = 0; $i < $getInfantNo; $i++): ?>
				<SearchTraveler Code="INF" Age="2" Key="inf<?=$i?>">
				    <Name xmlns="http://www.travelport.com/schema/common_v42_0" Prefix="MSTR" First="Jack" Last="Bauer" />
				</SearchTraveler>
			<?php endfor;?>
		<?php endif; ?>
	</SeatMapReq>
</soapenv:Body>
</soapenv:Envelope>