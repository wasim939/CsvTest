<?php
if(!defined('REQUEST_DIR'))
  die();
/**
 * @Author: Umar Hayat
 * @Date:   2019-07-29 19:10:30
 * @Last Modified by:   Umar Hayat
 * @Last Modified time: 2019-09-25 20:11:59
 */
?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">   
 <soapenv:Header/>   
 <soapenv:Body>      
  <air:LowFareSearchReq xmlns:air="http://www.travelport.com/schema/air_v42_0" xmlns:com="http://www.travelport.com/schema/common_v42_0" AuthorizedBy="user" SolutionResult="true" TargetBranch="<?=TP_TARGET_BRANCH?>" TraceId="trace">         
   <com:BillingPointOfSaleInfo OriginApplication="UAPI"/>    
   <air:SearchAirLeg>            
    <air:SearchOrigin>               
     <com:Airport Code="<?=$getDep?>"/>            
    </air:SearchOrigin>            
    <air:SearchDestination>               
     <com:Airport Code="<?=$getArr?>"/>            
    </air:SearchDestination>            
    <air:SearchDepTime PreferredTime="<?=$getDepDate?>"> 
      <?php if(isset($isDateFlexi) && $isDateFlexi): ?>
        <com:SearchExtraDays DaysBefore="1" DaysAfter="1" />
      <?php endif; ?>
    </air:SearchDepTime>        
   </air:SearchAirLeg> 
   <?php if($tripType == 'return'):?>        
	   <air:SearchAirLeg>            
	    <air:SearchOrigin>               
	     <com:Airport Code="<?=$getArr?>"/>            
	    </air:SearchOrigin>            
	    <air:SearchDestination>               
	     <com:Airport Code="<?=$getDep?>"/>            
	    </air:SearchDestination>            
	    <air:SearchDepTime PreferredTime="<?=$getReturnDate?>">
        <?php if(isset($isDateFlexi) && $isDateFlexi): ?>
          <com:SearchExtraDays DaysBefore="1" DaysAfter="1" />
        <?php endif; ?>
      </air:SearchDepTime>         
	   </air:SearchAirLeg> 
   <?php endif;?>       
   <air:AirSearchModifiers> 
    <air:PreferredProviders>               
     <com:Provider Code="<?=TP_GDS_CODE?>"/>            
    </air:PreferredProviders>    
	<air:PermittedCabins>
	 <com:CabinClass Type="<?=$getCabin?>"/>
	</air:PermittedCabins>     
   </air:AirSearchModifiers>
   <?php for($i = 0; $i < $getAdultNo; $i++): ?>
   		<com:SearchPassenger Code="ADT"/>
   <?php endfor;?>
   <?php if($getChildNo > 0): ?> 
   		<?php for($i = 0; $i < $getChildNo; $i++): ?>     
			<com:SearchPassenger Code="CNN"/>
		<?php endfor;?>
   <?php endif; ?>   
   <?php if($getInfantNo > 0): ?> 
   		<?php for($i = 0; $i < $getInfantNo; $i++): ?>     
   			<com:SearchPassenger Code="INF"/>
		<?php endfor;?>
   <?php endif; ?> 
  </air:LowFareSearchReq>   
 </soapenv:Body>
</soapenv:Envelope>