<?php
if(!defined('REQUEST_DIR'))
  die();
/**
 * @Author: Umar Hayat
 * @Date:   2019-07-31 17:31:08
 * @Last Modified by:   Umar Hayat
 * @Last Modified time: 2019-09-16 19:27:49
 */
?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">   
 <soapenv:Header/>   
 <soapenv:Body>
	<AirPriceReq xmlns="http://www.travelport.com/schema/air_v42_0" TraceId="4a4eb5e9-fcbe-44a8-86d9-8c3bf8ae9bfe" AuthorizedBy="Travelport" TargetBranch="<?=TP_TARGET_BRANCH?>">
	  <BillingPointOfSaleInfo xmlns="http://www.travelport.com/schema/common_v42_0" OriginApplication="uAPI" />
	  <AirItinerary>
	    <?php foreach($airSegmentRefKeys as $i =>  $airSegmentRefKey): ?>
			   	<AirSegment Key="<?=$airSegmentRefKey?>" AvailabilitySource="<?=$availabilitySources[$i]?>" Equipment="<?=$planes[$i]?>" AvailabilityDisplayType="<?=$availabilityDisplayTypes[$i]?>" Group="<?=$groups[$i]?>" Carrier="<?=$carriers[$i]?>" FlightNumber="<?=$flightNumbers[$i]?>" Origin="<?=$origins[$i]?>" Destination="<?=$destinations[$i]?>" DepartureTime="<?=$departs[$i]?>" ArrivalTime="<?=$arrivals[$i]?>" FlightTime="<?=$flightTimes[$i]?>" Distance="<?=$distances[$i]?>" ProviderCode="<?=TP_GDS_CODE?>" ClassOfService="<?=$classes[$i]?>">
			   	<?php if(isset($connections) && in_array($i, $connections)): ?>
			   		<Connection SegmentIndex="<?=$i?>"/>
			   	<?php endif; ?>
			   </AirSegment>
		<?php endforeach;?>
	  </AirItinerary>
	  <AirPricingModifiers InventoryRequestType="DirectAccess">
	    <BrandModifiers ModifierType="FareFamilyDisplay" />
	  </AirPricingModifiers>
	  	<?php for($i = 0; $i < $getAdultNo; $i++): ?>
			<SearchPassenger  xmlns="http://www.travelport.com/schema/common_v42_0" Code="ADT" BookingTravelerRef="adt<?=$i?>" Key="adt<?=$i?>" />
		<?php endfor;?>
		<?php if($getChildNo > 0): ?> 
			<?php for($i = 0; $i < $getChildNo; $i++): ?>     
			 	<SearchPassenger  xmlns="http://www.travelport.com/schema/common_v42_0" Code="CNN" Age="5" BookingTravelerRef="cnn<?=$i?>" Key="cnn<?=$i?>" />
			<?php endfor;?>
		<?php endif; ?>   
		<?php if($getInfantNo > 0): ?> 
			<?php for($i = 0; $i < $getInfantNo; $i++): ?>     
		     	<SearchPassenger  xmlns="http://www.travelport.com/schema/common_v42_0" Code="INF" BookingTravelerRef="inf<?=$i?>" Key="inf<?=$i?>" />
			<?php endfor;?>
		<?php endif; ?>
	  <AirPricingCommand>
	    <?php foreach($airSegmentRefKeys as $i =>  $airSegmentRefKey): ?>
		    <AirSegmentPricingModifiers AirSegmentRef="<?=$airSegmentRefKey?>" FareBasisCode="<?=$fareBasises[$i]?>">
		      <PermittedBookingCodes>
		        <BookingCode Code="<?=$classes[$i]?>" />
		      </PermittedBookingCodes>
		    </AirSegmentPricingModifiers>
		<?php endforeach;?>
	  </AirPricingCommand>
	  <!-- <FormOfPayment xmlns="http://www.travelport.com/schema/common_v42_0" Type="Credit" /> -->
	</AirPriceReq>
</soapenv:Body>
</soapenv:Envelope>