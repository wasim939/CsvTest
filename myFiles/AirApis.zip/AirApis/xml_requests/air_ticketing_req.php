<?php
if(!defined('REQUEST_DIR'))
  die();
/**
 * @Author: Umar Hayat
 * @Date:   2019-07-31 17:31:08
 * @Last Modified by:   Umar Hayat
 * @Last Modified time: 2019-09-17 20:31:22
 */
?>
<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" 
xmlns:air="http://www.travelport.com/schema/air_v42_0" 
xmlns:com="http://www.travelport.com/schema/common_v42_0">
  <soapenv:Body>
	<air:AirTicketingReq BulkTicket="false" ReturnInfoOnFail="true" TargetBranch="<?=TP_TARGET_BRANCH?>" AuthorizedBy="Travelport" TraceId="2">
		<com:BillingPointOfSaleInfo OriginApplication="UAPI"/>
		 
		<air:AirReservationLocatorCode><?=$air_reservation_locator_code?></air:AirReservationLocatorCode>
		<?php foreach($air_pricing_info_keys as $air_pricing_info_key): ?>
			<air:AirPricingInfoRef Key="<?=$air_pricing_info_key?>"/>
		<?php endforeach; ?>
		<air:AirTicketingModifiers>
 			<com:Commission Level="Fare" Type="PercentBase" Percentage="0.00"/>
 		</air:AirTicketingModifiers>
    </air:AirTicketingReq>
   </soapenv:Body>
</soapenv:Envelope>