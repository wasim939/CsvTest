<?php

/**
 * @Author: Umar Hayat
 * @Date:   2019-07-29 19:20:56
 * @Last Modified by:   mailm
 * @Last Modified time: 2020-02-14 22:31:56
 */
date_default_timezone_set("Asia/Karachi");

ob_start("ob_gzhandler");
set_time_limit(0);

header("Content-Type: application/json");

if(!function_exists("cleanInput"))
{
    function cleanInput($value)
    {
        $value = trim($value);
        $value = strip_tags($value);
        $value = htmlentities($value);
        return $value;
    }
}

//-------------------------------------- Essential Area ---------------------------------------------------
//if(strpos(__FILE__, "REST_STG") !== false)
{
    define('AIR_ENVIROMENT', "pre_production");
	define('ENVIROMENT', "live");
	error_reporting(0);
}
//elseif(strpos($_SERVER['HTTP_HOST'], "localhost") !== false)
//{
//	define('AIR_ENVIROMENT', "pre_production");
//	define('ENVIROMENT', "local");
//	error_reporting(E_ALL);
//}
//elseif(strpos($_SERVER['HTTP_HOST'], "bookme.pk") !== false)
//{
//	define('AIR_ENVIROMENT', "production");
//	define('ENVIROMENT', "live");
//	error_reporting(0);
//}
//else
//{
//	define('AIR_ENVIROMENT', "production");
//	define('ENVIROMENT', "live");
//	error_reporting(0);
//}

require_once getcwd() . "/AirModels/config.php";
require_once getcwd() . "/AirModels/DB.php";
require_once getcwd() . "/AirModels/AirException.php";
require_once getcwd() . "/AirModels/AirModel.php";


if(!function_exists("logToFile"))
{
    function logToFile($filename, $msg)
    { 
    	// open file
    	$fd 	= fopen($filename, "a");
    	// append date/time to message
    	$str 	= "[" . date("Y/m/d H:i:s", time()) . "] " . $msg. "\n"; 
    	// write string
    	fwrite($fd, $str . "\r\n");
    	// close file
    	fclose($fd);
    }
}

/*
 * Required Constants Defined
 */
define('DS', DIRECTORY_SEPARATOR);
define('REQUEST_DIR', "xml_requests");
define('LOW_FARE_REQUEST_FILE', "low_fare_search.php");
define('LOW_FARE_MULTI_REQUEST_FILE', "low_fare_search_multi.php");
// define('ALL_FARE_REQUEST_FILE', "all_fares_request.php");
// define('SEAT_RESERVATION_REQUEST_FILE', "seat_reservation_request.php");
define('SEAT_MAP_REQUEST_FILE', "seat_map_req.php");
define('AIR_PRICE_REQUEST_FILE', "air_price_req.php");
define('AIR_CREATE_RESERVATION_REQUEST_FILE', "air_create_reservation_req.php");
define('AIR_TICKETING_REQUEST_FILE', "air_ticketing_req.php");

//Constants Defination End

$interval_time 	= '2 MINUTE';
$interval_time2 = '00:02:00';
$source1 		= '';
$APITestMode 	= $APIPayment = $APIMoreData = 0;
$api_key 		= '';

if(!isset($_POST['api_key']) && !isset($verified))
{
	echo '{"status":false,"error":"Invalid API Key."}';
	logToFile("logs/API_NOKEY_LOG.txt", "Get -> ".$source1." >> ".json_encode($_GET)." | Post -> ".json_encode($_POST)."");
	die;
}
else if(isset($_POST['api_key']) && !isset($verified))
{
	$Authorization 	= "";
	$api_key        = preg_replace('/[^\da-z]/i', '', isset($_POST['api_key']) ? cleanInput($_POST['api_key']) : '');

	if (isset($_SERVER['Authorization']))
		$Authorization = str_replace("Basic ","",$_SERVER['Authorization']);
	else if (isset($_SERVER['REDIRECT_Authorization']))
		$Authorization = str_replace("Basic ","",$_SERVER['REDIRECT_Authorization']);
	else if (isset($_SERVER['HTTP_AUTHORIZATION']))
		$Authorization = str_replace("Basic ","",$_SERVER['HTTP_AUTHORIZATION']);
	else if (isset($_SERVER['REDIRECT_HTTP_AUTHORIZATION']))
		$Authorization = str_replace("Basic ","",$_SERVER['REDIRECT_HTTP_AUTHORIZATION']);

	try
	{
		$stmt 	= DB::prepare("SELECT * FROM xx_api_keys WHERE `key` = :id");
		$stmt->execute(['id' => $api_key]); 
		if(!$stmt->rowCount())
		{
			$err 	= $stmt->errorInfo();
			logToFile("DB_ERROR_LOGS.txt", "-> api_key: " . json_encode($err));
			die('{"status":false,"error":"Invalid API Key or Access Token."}');
		}
		else
		{
			$stmt->setFetchMode(PDO::FETCH_CLASS, 'stdClass');
			$obj = $stmt->fetch();

			if($obj->access_token != "" && $Authorization != $obj->access_token)
			{
				die('{"status":false,"error":"Invalid API Key or Access Token."}');
			}
			else
			{
				$source1 					= $obj->title;
				$APIFlexiFare 				= $obj->flexifare;
				$APITestMode 				= $obj->test;
				$APIPayment 				= $obj->payment;
				$APIMoreData 				= $obj->moredata;
				$API_IncludeHandlingCharges = $obj->include_handling_charges;
			}
		} 
	}
	catch(PDOException $e)
	{
		logToFile("DB_ERROR_LOGS.txt", "-> api_key: " . $e->getMessage()); 
		die('{"status":false,"error":"Invalid API Key or Access Token."}');
	}
}

//----------------------------------- AIR API -------------------------------------
//*********************************** 1. cities 
if(isset($_GET['countries']))
{
	try
	{ 
		$stmt 	= DB::prepare("SELECT * FROM `countries`");
		$stmt->execute(); 
		if(!$stmt->rowCount())
		{
			die('{"status":false,"error":"' . $e->getMessage() . '"}');
		}
		else
		{
			$stmt->setFetchMode(PDO::FETCH_CLASS, 'stdClass');
			die(json_encode($stmt->fetchAll()));
		}
	}
	catch(Exception $e)
	{
		die('{"status":false,"error":"' . $e->getMessage() . '"}');
	}
	catch(PDOException $e)
	{
		die('{"status":false,"error":"' . $e->getMessage() . '"}');
	}

}

if (isset($_GET['airports']))
{
	$country_code 	= isset($_POST['country_code']) ? preg_replace('/[^a-z]/i', '', $_POST['country_code']) : 0;
	try
	{
		require_once getcwd() . "/AirModels/Airport.php";

		die(json_encode(Airport::get($country_code)));
	}
	catch(AirException $e)
	{
		logToFile("DB_ERROR_LOGS.txt", "-> airports: " . $e->getMessage()); 
		die('{"status":false,"error":"Unable to Retrive Airports."}');
	}
}

if (isset($_GET['search_airports']))
{  
	$query 	= isset($_POST['query']) ? preg_replace('/[^a-z]/i', '', $_POST['query']) : "";
	try
	{
		if(empty($query))
		{
			throw new AirException("Query Cannot Be Empty");
		}

		require_once getcwd() . "/AirModels/Airport.php";

		die(json_encode(Airport::search($query)));
	}
	catch(AirException $e)
	{
		logToFile("DB_ERROR_LOGS.txt", "-> airports: " . $e->getMessage()); 
		die('{"status":false,"error":"Unable to Retrive Airports."}');
	}
}
//----------------------------------- AIR API -------------------------------------
//*********************************** 2. airlines
if (isset($_GET['airlines']))
{  
	$airline_code = (isset($_POST['code']) ? preg_replace('/[^\da-z]/i', '', $_POST['code']) : 0);
	try
	{
		require_once getcwd() . "/AirModels/Airline.php";

		die(json_encode(Airline::get($airline_code)));
	}
	catch(AirException $e)
	{
		logToFile("DB_ERROR_LOGS.txt", "-> airports: " . $e->getMessage()); 
		die('{"status":false,"error":"Unable to Retrive Airlines."}');
	}
}

//----------------------------------- AIR API -------------------------------------
//*********************************** 3. Search
if(isset($_GET['search']))
{
	header("Content-Type: application/json");

	$response 		= ['status' => '', 'msg' => '', 'data' => array()];

	$getDep 		= isset($_POST['from']) ? $_POST['from'] : '';
	$getArr 		= isset($_POST['to']) ? $_POST['to'] : '';
	$getDepDate 	= isset($_POST['dep_date']) ? $_POST['dep_date'] : '';
	$getReturnDate 	= isset($_POST['return_date']) ? $_POST['return_date'] : '';
	$getCabin 		= isset($_POST['cabin']) ? $_POST['cabin'] : 'Economy';
	$getAdultNo 	= (int) (isset($_POST['no_of_adults']) ? $_POST['no_of_adults'] : 0);
	$getChildNo 	= (int) (isset($_POST['no_of_children']) ? $_POST['no_of_children'] : 0);
	$getInfantNo 	= (int) (isset($_POST['no_of_infants']) ? $_POST['no_of_infants'] : 0);
	$getGroupBy 	= (int) (isset($_POST['group_by_carrier']) ? $_POST['group_by_carrier'] : 0);
	$isDateFlexi 	= isset($_POST['flexible_dates']) ? true : false;
	$scrapeData 	= isset($_POST['scrape']) ? true : false;

	$tripType 		= 'single';

	if($_POST['api_key'] == '464a2f4df692438053dd30df4561eec1')
	{
		$scrapeData = true;
	}

	if(empty($getDep))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Departure Required.';
		die(json_encode($response));
	}
	if(empty($getArr))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Arrival Required.'; 
		die(json_encode($response));
	}

	if(empty($getDepDate))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Departure Date Required.'; 
		die(json_encode($response));
	}
	elseif(!strtotime($getDepDate))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Invalid Departure Date Format.'; 
		die(json_encode($response));
	}

	if(!empty($getReturnDate) && !strtotime($getReturnDate))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Invalid Return Date Format.'; 
		die(json_encode($response));
	}
	elseif(!empty($getReturnDate))
	{
		$tripType	= 'return';
	}

	if(!in_array($getCabin, ['Economy', 'Business']))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Invalid Cabin Class.'; 
		die(json_encode($response));
	}

	if($getAdultNo == 0)
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Adult passengers cannot be zero.'; 
		die(json_encode($response));
	}

	if($getAdultNo < $getInfantNo)
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Number of infants must not exceed number of adult passengers.'; 
		die(json_encode($response));
	}

	//Getting XML ready for API request
	ob_start();
		require getcwd() . DS . REQUEST_DIR . DS . LOW_FARE_REQUEST_FILE;
	$requestXML = ob_get_clean();
	//End

	require_once getcwd() . DS . "AirModels" . DS . "FlightSearch.php";

	try 
	{
		$serene_data 	= [];
		$airblue_data 	= [];

		if($scrapeData && strtolower($getCabin) == 'economy' && in_array(strtoupper($getDep), ['LYP', 'ISB', 'KHI', 'LHE', 'PEW', 'UET']) && in_array(strtoupper($getArr), ['LYP', 'ISB', 'KHI', 'LHE', 'PEW', 'UET']))
		{
			require_once getcwd() . DS . "AirModels" . DS . "SereneFlightSearch.php";
			$serene_data = SereneFlightSearch::makeRequest($_POST);
		}

		// if($scrapeData && strtolower($getCabin) == 'economy' && in_array(strtoupper($getDep), ['LYP', 'ISB', 'KHI', 'LHE', 'PEW', 'UET', 'MUX']) && in_array(strtoupper($getArr), ['LYP', 'ISB', 'KHI', 'LHE', 'PEW', 'UET', 'MUX']))
		// {
		// 	require_once getcwd() . DS . "AirModels" . DS . "AirblueFlightSearch.php";
		// 	$airblue_data = AirblueFlightSearch::makeRequest($_POST);
		// }

		$ref_id = md5(time() . uniqid() . rand(99, 99999));

		FlightSearch::makeRequest($requestXML);

		$data 	= FlightSearch::parseResponse($tripType == 'return' ? true : false);

		if(!empty($serene_data) && isset($serene_data[0]) && isset($serene_data[0]['outbound_route']))
		{
			$data = array_merge($serene_data, $data);
			usort($data, function($a, $b) {
			    return $a['approx_total_price'] <=> $b['approx_total_price'];
			});

			file_put_contents(getcwd() . '/cache/air/' . FlightSearch::getCacheFilename() . '_parsed.dat', json_encode($data));
		}

		if(!copy(getcwd() . '/cache/air/' . FlightSearch::getCacheFilename() . '_raw.dat', getcwd() . '/cache/air/reference_data/' . $ref_id . '_raw_search.dat') || !copy(getcwd() . '/cache/air/' . FlightSearch::getCacheFilename() . '_parsed.dat', getcwd() . '/cache/air/reference_data/' . $ref_id . '_parsed_search.dat'))
		{
			throw new AirException("Something Went Wrong. Please Try Again");
		}

		$response['status'] = "success";
		$response['msg'] 	= count($data) . " matching results.";
		$response['ref_id']	= $ref_id;
		$response['data'] 	= $data;
	}
	catch (AirException $e) 
	{
		$response['status'] = "error";
		$response['msg'] 	= $e->errorMessage();
	}

	die(json_encode($response));
}
elseif(isset($_GET['multi_search']))
{
	header("Content-Type: application/json");

	$response 		= ['status' => '', 'msg' => '', 'data' => array()];

	$getDep 		= isset($_POST['froms']) ? $_POST['froms'] : '';
	$getArr 		= isset($_POST['tos']) ? $_POST['tos'] : '';
	$getDepDate 	= isset($_POST['dep_dates']) ? $_POST['dep_dates'] : '';
	$getCabin 		= isset($_POST['cabin']) ? $_POST['cabin'] : 'Economy';
	$getAdultNo 	= (int) (isset($_POST['no_of_adults']) ? $_POST['no_of_adults'] : 0);
	$getChildNo 	= (int) (isset($_POST['no_of_children']) ? $_POST['no_of_children'] : 0);
	$getInfantNo 	= (int) (isset($_POST['no_of_infants']) ? $_POST['no_of_infants'] : 0);
	$getGroupBy 	= (int) (isset($_POST['group_by_carrier']) ? $_POST['group_by_carrier'] : 0);

	$tripType 		= 'multi_city';

	if(empty($getDep))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Departure Required.';
		die(json_encode($response));
	}
	if(empty($getArr))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Arrival Required.'; 
		die(json_encode($response));
	}

	if(empty($getDepDate))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Departure Date Required.'; 
		die(json_encode($response));
	}
	elseif(!strtotime($getDepDate))
	{
	    foreach($getDepDate as $date)
	    {
	        if(strtotime($date))
	            continue;
		    $response['status']	= 'error'; 
		    $response['msg']	= 'Invalid Departure Date Format.'; 
		    die(json_encode($response));
	    }
	}

	if(!in_array($getCabin, ['Economy', 'Business']))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Invalid Cabin Class.'; 
		die(json_encode($response));
	}

	if($getAdultNo == 0)
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Adult passengers cannot be zero.'; 
		die(json_encode($response));
	}

	if($getAdultNo < $getInfantNo)
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Number of infants must not exceed number of adult passengers.'; 
		die(json_encode($response));
	}

	//Getting XML ready for API request
	ob_start();
		require getcwd() . DS . REQUEST_DIR . DS . LOW_FARE_MULTI_REQUEST_FILE;
	$requestXML = ob_get_clean();
	//End

	require_once getcwd() . DS . "AirModels" . DS . "MultiFlightSearch.php";

	try 
	{
		$ref_id = md5(time() . uniqid() . rand(99, 99999));

		MultiFlightSearch::makeRequest($requestXML);

		$data 	= MultiFlightSearch::parseResponse();

		if(!copy(getcwd() . '/cache/air/' . MultiFlightSearch::getCacheFilename() . '_raw.dat', getcwd() . '/cache/air/reference_data/' . $ref_id . '_raw_search.dat') || !copy(getcwd() . '/cache/air/' . MultiFlightSearch::getCacheFilename() . '_parsed.dat', getcwd() . '/cache/air/reference_data/' . $ref_id . '_parsed_search.dat'))
		{
			throw new AirException("Something Went Wrong. Please Try Again");
		}

		$response['status'] = "success";
		$response['msg'] 	= count($data) . " matching results.";
		$response['ref_id']	= $ref_id;
		$response['data'] 	= $data;
	}
	catch (AirException $e) 
	{
		$response['status'] = "error";
		$response['msg'] 	= $e->errorMessage();
	}

	die(json_encode($response));
}
elseif(isset($_GET['air_price']))
{
	$response 		= ['status' => '', 'msg' => '', 'data' => array()];

	$refId 			= isset($_POST['ref_id']) ? $_POST['ref_id'] : "";
	$journeyRefId 	= isset($_POST['journey_ref_id']) ? $_POST['journey_ref_id'] : "";
	$getAdultNo 	= (int) (isset($_POST['no_of_adults']) ? $_POST['no_of_adults'] : 0);
	$getChildNo 	= (int) (isset($_POST['no_of_children']) ? $_POST['no_of_children'] : 0);
	$getInfantNo 	= (int) (isset($_POST['no_of_infants']) ? $_POST['no_of_infants'] : 0);

	if(empty($refId))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Reference ID Required.'; 
		die(json_encode($response));
	}
	elseif(!file_exists(getcwd() . '/cache/air/reference_data/' . $refId . '_raw_search.dat') || !file_exists(getcwd() . '/cache/air/reference_data/' . $refId . '_parsed_search.dat'))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Invalid Reference ID.'; 
		die(json_encode($response));
	}

	if(empty($journeyRefId))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Invalid Journey Reference ID.'; 
		die(json_encode($response));
	}

	if($getAdultNo == 0)
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Adult passengers cannot be zero.'; 
		die(json_encode($response));
	}

	if($getAdultNo < $getInfantNo)
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Number of infants must not exceed number of adult passengers.'; 
		die(json_encode($response));
	}

	$isSerene = false;
	if(strpos($journeyRefId, 'ER') !== false)
	{
		$isSerene = true;
	}

	/*Stored JSON Parsing*/
	try
	{
		$reference_response = json_decode(file_get_contents(getcwd() . '/cache/air/reference_data/' . $refId . '_parsed_search.dat'), true);
		if(json_last_error() != JSON_ERROR_NONE)
		{
			throw new AirException("Something Went Wrong. Please Search Again.");
		}
		$index = 0;
		$airSegmentRefKeys		= [];
		$availabilitySources 	= [];
		$planes 				= [];
		$fareBasises 			= [];
		$availabilityDisplayTypes = [];
		$groups	 				= [];
		$carriers 				= [];
		$flightNumbers			= [];
		$origins 				= [];
		$destinations 			= [];
		$departs 				= [];
		$arrivals 				= [];
		$flightTimes 			= [];
		$distances 				= [];
		$classes				= [];
		$connections 			= [];
		$tripType 				= "one_way";

		$flight_info 			= [];

		foreach($reference_response as $flight)
		{
			if($flight['journey_ref_id'] == $journeyRefId)
			{
				if($isSerene)
				{
					$index = 1;
					$flight_info = $flight;
					break;
				}

				foreach($flight['outbound_route'] as $route)
				{
					if(!isset($route['air_segment_ref_key']))
						continue;
					$airSegmentRefKeys[$index]		= $route['air_segment_ref_key'];
					$availabilitySources[$index] 	= $route['availability_source'];
					$planes[$index] 				= $route['plane'];
					$fareBasises[$index] 			= $route['fare_basis'];
					$availabilityDisplayTypes[$index] = $route['availability_display_type'];
					$groups[$index]	 				= $route['group'];
					$carriers[$index] 				= $route['carrier'];
					$flightNumbers[$index]			= $route['flight_number'];
					$origins[$index] 				= $route['from'];
					$destinations[$index] 			= $route['to'];
					$departs[$index] 				= $route['depart'];
					$arrivals[$index] 				= $route['arrival'];
					$flightTimes[$index] 			= $route['flight_time'];
					$distances[$index] 				= $route['distance'];
					$classes[$index]				= $route['class'];
					$index++;
					$airline 						= $route['airline'];
					$class 							= $route['cabin_class'];
				}

				$carrier 		= $carriers[0];
				$from 			= $origins[0];
				$to 			= $destinations[$index - 1];

				if(isset($flight['inbound_route']))
				{
					foreach($flight['inbound_route'] as $route)
					{
						if(!isset($route['air_segment_ref_key']))
							continue;
						$airSegmentRefKeys[$index]		= $route['air_segment_ref_key'];
						$availabilitySources[$index] 	= $route['availability_source'];
						$planes[$index] 				= $route['plane'];
						$fareBasises[$index] 			= $route['fare_basis'];
						$availabilityDisplayTypes[$index] = $route['availability_display_type'];
						$groups[$index]	 				= $route['group'];
						$carriers[$index] 				= $route['carrier'];
						$flightNumbers[$index]			= $route['flight_number'];
						$origins[$index] 				= $route['from'];
						$destinations[$index] 			= $route['to'];
						$departs[$index] 				= $route['depart'];
						$arrivals[$index] 				= $route['arrival'];
						$flightTimes[$index] 			= $route['flight_time'];
						$distances[$index] 				= $route['distance'];
						$classes[$index]				= $route['class'];
						$index++;
					}
				}
				$connections 	= isset($flight['connection']) ? $flight['connection'] : [];
				$tripType 		= isset($flight['direction']) ? $flight['direction'] : "one_way";
				break;
			}
		}
		if($index == 0)
		{
			throw new AirException("Invalid Journey Reference ID.");
		}
	}
	catch (AirException $e) 
	{
		$response['status'] = "error";
		$response['msg'] 	= $e->errorMessage();
		die(json_encode($response));
	}
	/*End Parsing*/

	if($isSerene && !empty($flight_info))
	{
		require_once getcwd() . DS . "AirModels" . DS . "SereneAirPrice.php";
	}
	else
	{
		//Getting XML ready for API request
		ob_start();
			require getcwd() . DS . REQUEST_DIR . DS . AIR_PRICE_REQUEST_FILE;
		$requestXML = ob_get_clean();
		//End

		require_once getcwd() . DS . "AirModels" . DS . "AirPrice.php";
	}

	try 
	{
		if($isSerene && !empty($flight_info))
		{
			$flight_info['no_of_adults'] 	= $getAdultNo;
			$flight_info['no_of_children'] 	= $getChildNo;
			$flight_info['no_of_infants'] 	= $getInfantNo;

			$data = SereneAirPrice::makeRequest($flight_info);

			if(!copy(getcwd() . '/cache/air/' . SereneAirPrice::getCacheFilename() . '_raw.dat', getcwd() . '/cache/air/reference_data/' . $refId . '_raw_price.dat') || !copy(getcwd() . '/cache/air/' . SereneAirPrice::getCacheFilename() . '_parsed.dat', getcwd() . '/cache/air/reference_data/' . $refId . '_parsed_price.dat'))
			{
				throw new AirException("Something Went Wrong. Please Try Again".SereneAirPrice::getCacheFilename());
			}
		}
		else
		{
			$requestXML = preg_replace('/FareBasisCode=\".+\"/', '', $requestXML);

			AirPrice::makeRequest($requestXML);
			$data 	= AirPrice::parseResponse(['direction' => $tripType, 'carrier' => $carrier, 'airline' => $airline, 'class' => $class, 'from' => $from, 'to' => $to, 'no_of_adults' => $getAdultNo, 'no_of_children' => $getChildNo, 'no_of_infants' => $getInfantNo]);

			if(!copy(getcwd() . '/cache/air/' . AirPrice::getCacheFilename() . '_raw.dat', getcwd() . '/cache/air/reference_data/' . $refId . '_raw_price.dat') || !copy(getcwd() . '/cache/air/' . AirPrice::getCacheFilename() . '_parsed.dat', getcwd() . '/cache/air/reference_data/' . $refId . '_parsed_price.dat'))
			{
				throw new AirException("Something Went Wrong. Please Try Again");
			}
		}

		$response['status'] = "success";
		$response['msg'] 	= count($data) . " matching results.";
		$response['data'] 	= $data;
	}
	catch (AirException $e) 
	{
		$response['status'] = "error";
		$response['msg'] 	= $e->errorMessage();
	}

	die(json_encode($response));
}
elseif(isset($_GET['seat_map']))
{
	header("Content-Type: application/json");

	$response 		= ['status' => '', 'msg' => '', 'data' => array()];

	$refId 			= isset($_POST['ref_id']) ? $_POST['ref_id'] : "";
	$getAdultNo 	= (int) (isset($_POST['no_of_adults']) ? $_POST['no_of_adults'] : 0);
	$getChildNo 	= (int) (isset($_POST['no_of_children']) ? $_POST['no_of_children'] : 0);
	$getInfantNo 	= (int) (isset($_POST['no_of_infants']) ? $_POST['no_of_infants'] : 0);

	if(empty($refId))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Reference ID Required.'; 
		die(json_encode($response));
	}
	elseif(!file_exists(getcwd() . '/cache/air/reference_data/' . $refId . '_raw_price.dat') || !file_exists(getcwd() . '/cache/air/reference_data/' . $refId . '_parsed_price.dat'))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Invalid Reference ID.'; 
		die(json_encode($response));
	}

	if($getAdultNo == 0)
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Adult passengers cannot be zero.'; 
		die(json_encode($response));
	}

	if($getAdultNo < $getInfantNo)
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Number of infants must not exceed number of adult passengers.'; 
		die(json_encode($response));
	}

	/*Stored JSON Parsing*/
	try
	{
		$reference_response = json_decode(file_get_contents(getcwd() . '/cache/air/reference_data/' . $refId . '_parsed_price.dat'), true);
		if(json_last_error() != JSON_ERROR_NONE)
		{
			throw new AirException("Something Went Wrong. Please Search Again.");
		}
		$index = 0;
		$airSegmentRefKeys		= [];
		// $availabilitySources 	= [];
		$planes 				= [];
		// $fareBasises 			= [];
		$availabilityDisplayTypes = [];
		$groups	 				= [];
		$carriers 				= [];
		$flightNumbers			= [];
		$origins 				= [];
		$destinations 			= [];
		$departs 				= [];
		$arrivals 				= [];
		$flightTimes 			= [];
		$distances 				= [];
		$classes				= [];
		$hostTokens 			= [];
		foreach($reference_response['air_segment'] as $flight)
		{
			$airSegmentRefKeys[$index]		= $flight['air_segment_ref_key'];
			// $availabilitySources[$index] 	= $flight['availability_source'];
			$planes[$index] 				= $flight['plane'];
			// $fareBasises[$index] 			= $flight['fare_basis'];
			$availabilityDisplayTypes[$index] = $flight['availability_display_type'];
			$groups[$index]	 				= $flight['group'];
			$carriers[$index] 				= $flight['carrier'];
			$flightNumbers[$index]			= $flight['flight_number'];
			$origins[$index] 				= $flight['from'];
			$destinations[$index] 			= $flight['to'];
			$departs[$index] 				= $flight['depart'];
			$arrivals[$index] 				= $flight['arrival'];
			$flightTimes[$index] 			= $flight['flight_time'];
			$distances[$index] 				= $flight['distance'];
			$classes[$index]				= $flight['class'];
			$hostTokenKeys[$index]			= $flight['host_token']['key'];
			$hostTokens[$index]				= $flight['host_token']['token'];
			$index++;
		}

		if($index == 0)
		{
			throw new AirException("Invalid Journey Reference ID.");
		}
	}
	catch (AirException $e) 
	{
		$response['status'] = "error";
		$response['msg'] 	= $e->errorMessage();
		die(json_encode($response));
	}

	//Getting XML ready for API request
	ob_start();
		require getcwd() . DS . REQUEST_DIR . DS . SEAT_MAP_REQUEST_FILE;
	$requestXML = ob_get_clean();
	//End

	require_once getcwd() . DS . "AirModels" . DS . "SeatMap.php";

	try 
	{
		SeatMap::makeRequest($requestXML);
		$data 	= SeatMap::parseResponse();

		if(!copy(getcwd() . '/cache/air/' . SeatMap::getCacheFilename() . '_raw.dat', getcwd() . '/cache/air/reference_data/' . $refId . '_raw_map.dat') || !copy(getcwd() . '/cache/air/' . SeatMap::getCacheFilename() . '_parsed.dat', getcwd() . '/cache/air/reference_data/' . $refId . '_parsed_map.dat'))
		{
			throw new AirException("Something Went Wrong. Please Try Again");
		}

		$response['status'] = "success";
		$response['msg'] 	= count($data) . " matching results.";
		$response['data'] 	= $data;
	}
	catch (AirException $e) 
	{
		$response['status'] = "error";
		$response['msg'] 	= $e->errorMessage();
	}

	die(json_encode($response));
}
elseif(isset($_GET['reservation']))
{
	header("Content-Type: application/json");

	$response 		= ['status' => '', 'msg' => '', 'data' => array()];

	$user_id 		= $_POST['user_id'] ?? '';
	$refId 			= isset($_POST['ref_id']) ? $_POST['ref_id'] : "";
	$journeyRefId 	= isset($_POST['journey_ref_id']) ? $_POST['journey_ref_id'] : "";
	$getAdultNo 	= (int) (isset($_POST['no_of_adults']) ? $_POST['no_of_adults'] : 0);
	$getChildNo 	= (int) (isset($_POST['no_of_children']) ? $_POST['no_of_children'] : 0);
	$getInfantNo 	= (int) (isset($_POST['no_of_infants']) ? $_POST['no_of_infants'] : 0);

	$travelerTypes 	= (isset($_POST['traveler_type']) && is_array($_POST['traveler_type'])) ? $_POST['traveler_type'] : [];
	$prefixes 		= (isset($_POST['prefix']) && is_array($_POST['prefix'])) ? $_POST['prefix'] : [];
	$firstnames 	= (isset($_POST['firstname']) && is_array($_POST['firstname'])) ? $_POST['firstname'] : [];
	$lastnames 		= (isset($_POST['lastname']) && is_array($_POST['lastname'])) ? $_POST['lastname'] : [];
	$genders 	 	= (isset($_POST['gender']) && is_array($_POST['gender'])) ? $_POST['gender'] : [];
	$ages 	 		= (isset($_POST['age']) && is_array($_POST['age'])) ? $_POST['age'] : [];
	$dobs 		 	= (isset($_POST['dob']) && is_array($_POST['dob'])) ? $_POST['dob'] : [];
	$seats 		 	= (isset($_POST['seat']) && is_array($_POST['seat'])) ? $_POST['seat'] : [];

	$cnic 			= isset($_POST['cnic']) ? $_POST['cnic'] : '';
	$addressName 	= isset($_POST['address_name']) ? $_POST['address_name'] : ''; 
	$street 		= isset($_POST['street']) ? $_POST['street'] : ''; 
	$city 			= isset($_POST['city']) ? $_POST['city'] : ''; 
	$state 			= isset($_POST['state']) ? $_POST['state'] : ''; 
	$postalCode 	= isset($_POST['postal_code']) ? $_POST['postal_code'] : ''; 
	$country 		= isset($_POST['country']) ? $_POST['country'] : ''; 
	$areaCode 		= isset($_POST['area_code']) ? $_POST['area_code'] : '';
	$countryCode	= isset($_POST['country_code']) ? $_POST['country_code'] : '';
	$location 		= isset($_POST['location']) ? $_POST['location'] : '';
	$phoneNumber 	= isset($_POST['phone_number']) ? $_POST['phone_number'] : '';
	$email 			= isset($_POST['email']) ? $_POST['email'] : '';


	$carrier 		= "";
	$passenger_country 	= isset($_POST['passenger_country']) ? $_POST['passenger_country'] : [];
	$passport_no 	= isset($_POST['passport_no']) ? $_POST['passport_no'] : [];
	$nationality 	= isset($_POST['nationality']) ? $_POST['nationality'] : [];
	$passport_expiry= isset($_POST['passport_expiry']) ? $_POST['passport_expiry'] : [];

	$isInternationalFlight = false;

	if(empty($refId))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Reference ID Required.'; 
		die(json_encode($response));
	}
	elseif(!file_exists(getcwd() . '/cache/air/reference_data/' . $refId . '_raw_price.dat') || !file_exists(getcwd() . '/cache/air/reference_data/' . $refId . '_parsed_price.dat'))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Invalid Reference ID.'; 
		die(json_encode($response));
	}
	else
	{
		$reference_response = json_decode(file_get_contents(getcwd() . '/cache/air/reference_data/' . $refId . '_parsed_price.dat'), true);
		if(isset($reference_response['air_segment']) && isset($reference_response['air_segment'][0]['carrier']))
		{
			$carrier 	= $reference_response['air_segment'][0]['carrier'];
			foreach($reference_response['air_segment'] as $temp)
			{
    			if(!in_array($temp['from'], ['BHW','LYP','GWD','GIL','JAG','KHI','LHE','XJM','MFG','MWD','MJD','MUX','WNS','PJG','PSI','PEW','UET','RYK','RAZ','SKZ','SDT','SUL','BDN','WAF','PZH','BNP','BHV','CJL','DBA','DEA','DSK','JIW','HDD','KDD','ORW','PAJ','KDU','SYW','TUK','SKT','KCF','RZS','ATG','SGI','ISB']) || !in_array($temp['to'], ['BHW','LYP','GWD','GIL','JAG','KHI','LHE','XJM','MFG','MWD','MJD','MUX','WNS','PJG','PSI','PEW','UET','RYK','RAZ','SKZ','SDT','SUL','BDN','WAF','PZH','BNP','BHV','CJL','DBA','DEA','DSK','JIW','HDD','KDD','ORW','PAJ','KDU','SYW','TUK','SKT','KCF','RZS','ATG','SGI','ISB']))
    			{
    				$isInternationalFlight = true;
    			}
			}
		}
	}

	if(empty($journeyRefId))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Invalid Journey Reference ID.'; 
		die(json_encode($response));
	}

	if($isInternationalFlight)
	{
		if(empty($passenger_country))
		{
			$response['status']	= 'error'; 
			$response['msg']	= 'Passenger\'s Country is Required.'; 
			die(json_encode($response));
		}
		if(empty($passport_no))
		{
			$response['status']	= 'error'; 
			$response['msg']	= 'Passenger No is Required.'; 
			die(json_encode($response));
		}
		if(empty($nationality))
		{
			$response['status']	= 'error'; 
			$response['msg']	= 'Passenger\'s Nationality is Required.'; 
			die(json_encode($response));
		}
		if(empty($passport_expiry))
		{
			$response['status']	= 'error'; 
			$response['msg']	= 'Passport Expiry is Required.'; 
			die(json_encode($response));
		}
	}

	if(empty($travelerTypes))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Traveler Type is Required.'; 
		die(json_encode($response));
	}

	if(empty($prefixes))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Name prefix is Required.'; 
		die(json_encode($response));
	}

	if(empty($firstnames) || empty($lastnames))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Name is Required.'; 
		die(json_encode($response));
	}

	if($isInternationalFlight && empty($genders))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Gender is Required.'; 
		die(json_encode($response));
	}

	// if(empty($ages))
	// {
	// 	$response['status']	= 'error'; 
	// 	$response['msg']	= 'Age is Required.'; 
	// 	die(json_encode($response));
	// }

	if($isInternationalFlight && empty($dobs))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'DOB is Required.'; 
		die(json_encode($response));
	}

	if(empty($seats) || !is_array($seats))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Seat Info is Required.'; 
		die(json_encode($response));
	}

	if(!$isInternationalFlight && empty($cnic))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'CNIC No is Required.'; 
		die(json_encode($response));
	}

	if($getAdultNo == 0)
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Adult passengers cannot be zero.'; 
		die(json_encode($response));
	}

	if($getAdultNo < $getInfantNo)
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Number of infants must not exceed number of adult passengers.'; 
		die(json_encode($response));
	}

	// if(empty($addressName))
	// {
	// 	$response['status']	= 'error'; 
	// 	$response['msg']	= 'Address is Required.'; 
	// 	die(json_encode($response));
	// }

	// if(empty($street))
	// {
	// 	$response['status']	= 'error'; 
	// 	$response['msg']	= 'Street is Required.'; 
	// 	die(json_encode($response));
	// }

	// if(empty($city))
	// {
	// 	$response['status']	= 'error'; 
	// 	$response['msg']	= 'City is Required.'; 
	// 	die(json_encode($response));
	// }

	// if(empty($state))
	// {
	// 	$response['status']	= 'error'; 
	// 	$response['msg']	= 'State is Required.'; 
	// 	die(json_encode($response));
	// }

	// if(empty($postalCode))
	// {
	// 	$response['status']	= 'error'; 
	// 	$response['msg']	= 'Postal Code is Required.'; 
	// 	die(json_encode($response));
	// }

	if(empty($country))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Country is Required.'; 
		die(json_encode($response));
	}

	if(empty($phoneNumber))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Phone Number is Required.'; 
		die(json_encode($response));
	}

	if(empty($email))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Email is Required.'; 
		die(json_encode($response));
	}

	$isSerene = false;
	if(strpos($journeyRefId, 'ER') !== false)
	{
		$isSerene = true;
	}

	if(!$isSerene)
	{
		/*Stored JSON Parsing*/
		try
		{
			$temp_xml 	= file_get_contents(getcwd() . '/cache/air/reference_data/' . $refId . '_raw_price.dat');
			if(empty($temp_xml))
			{
				throw new AirException("Encoding Error.");
				return false;
			}

			$temp_xml 	= simplexml_load_String($temp_xml);
			$Results 	= $temp_xml->children('SOAP', true);

			foreach($Results->children('SOAP', true) as $fault)
			{
				if(strcmp($fault->getName(), 'Fault') == 0)
				{
					throw new AirException("Error occurred request/response processing: " . $fault->__toString());
					return false;
				}
			}
			$Results 		= $Results->children('air', true);
			$air_segments 	= [];
			$pricing_infos 	= [];
			$host_tokens 	= [];
			foreach($Results->children('air', true) as $airPriceResult)
			{
				if(strcmp($airPriceResult->getName(), 'AirPriceResult') == 0)
				{
					foreach($airPriceResult->children('air', true) as $airPricingSolution)
					{
						if(strcmp($airPricingSolution->getName(), 'AirPricingSolution') == 0)
						{
							foreach($airPricingSolution->attributes() as $key => $val)
							{
								if(strcmp($key, 'Key') == 0)
								{
									$aps_key = (string) $val;
								}
								elseif(strcmp($key, 'TotalPrice') == 0)
								{
									$aps_total_price = (string) $val;
								}
								elseif(strcmp($key, 'BasePrice') == 0)
								{
									$aps_base_price = (string) $val;
								}
								elseif(strcmp($key, 'ApproximateTotalPrice') == 0)
								{
									$aps_approx_total_price = (string) $val;
								}
								elseif(strcmp($key, 'ApproximateBasePrice') == 0)
								{
									$aps_approx_base_price = (string) $val;
								}
								elseif(strcmp($key, 'EquivalentBasePrice') == 0)
								{
									$aps_eqv_price = (string) $val;
								}
								elseif(strcmp($key, 'Taxes') == 0)
								{
									$aps_taxes = (string) $val;
								}
								elseif(strcmp($key, 'Fees') == 0)
								{
									$aps_fee = (string) $val;
								}
								elseif(strcmp($key, 'ApproximateTaxes') == 0)
								{
									$aps_approx_taxes = (string) $val;
								}
								elseif(strcmp($key, 'QuoteDate') == 0)
								{
									$aps_quote_date = (string) $val;
								}
							}

							foreach($airPricingSolution->children('air', true) as $airPricingInfo)
							{
								if(strcmp($airPricingInfo->getName(), 'AirPricingInfo') == 0)
								{
									$temp 			= preg_replace('/TaxAmount=\".+\"/', '', $airPricingInfo->asXML());
									$temp 			= preg_replace('/PlatingCarrier=\".+\"/', '', $temp);

									if(strpos($temp, 'PassengerType Code="ADT"') !== false)
									{
										$passenger_info_type = 'ADT';
									}
									elseif(strpos($temp, 'PassengerType Code="CNN"') !== false)
									{
										$passenger_info_type = 'CNN';
									}
									elseif(strpos($temp, 'PassengerType Code="INF"') !== false)
									{
										$passenger_info_type = 'INF';
									}

									$pCount 		= 0;
									$temp 			= preg_replace_callback('/<air:PassengerType.*\/>/', function($matches) use(&$pCount) {
										return "PESSENGER_" . $pCount++;
										}, $temp);

									$pCount 		= 0;
									foreach($travelerTypes as $i => $traveler_type)
									{
										if($traveler_type == $passenger_info_type)
										{
											$temp = str_replace("PESSENGER_" . ($pCount++), '<air:PassengerType Code="'. $traveler_type .'" BookingTravelerRef="'. strtolower($traveler_type) . $i .'" />', $temp);
											// break;
										}
									}

									// foreach($travelerTypes as $i => $traveler_type)
									// {
									// 	$temp = str_replace("PESSENGER_" . $i, '', $temp);
									// }

									$temp 	= preg_replace(['~LanguageCode="([A-Za-z0-9 ]*)"~', '~Tag="([A-Za-z0-9 ]*)"~', '~DisplayOrder="([A-Za-z0-9 ]*)"~', '~<common_v42_0:Endorsement.*\/>~'], '', $temp);

									// if(substr($temp, '<air:PassengerType Code="ADT"/>') !== false)
									// {
									// 	$temp = str_replace('<air:PassengerType Code="ADT"/>', '', $temp);
									// 	$temp = str_replace('</air:FareCalc>', '</air:FareCalc><air:PassengerType Code="ADT"/>', $temp);
									// }
									// elseif(substr($temp, '<air:PassengerType Code="CNN" Age="5"/>') !== false)
									// {
									// 	$temp = str_replace('<air:PassengerType Code="CNN" Age="5"/>', '', $temp);
									// 	$temp = str_replace('</air:FareCalc>', '</air:FareCalc><air:PassengerType Code="CNN" Age="5"/>', $temp);
									// }
									// elseif(substr($temp, '<air:PassengerType Code="INF"/>') !== false)
									// {
									// 	$temp = str_replace('<air:PassengerType Code="INF"/>', '', $temp);
									// 	$temp = str_replace('</air:FareCalc>', '</air:FareCalc><air:PassengerType Code="INF"/>', $temp);
									// }
									$pricing_infos[] = $temp;
									// if($pCount > 1)
									// {
									// 	for($i = 1; $i < $pCount; $i++)
									// 	{
									// 		if($passenger_info_type == 'ADT')
									// 		{
									// 			$pricing_infos[] = str_replace('adt0', 'adt' . $i, $temp);
									// 		}
									// 		elseif($passenger_info_type == 'CNN')
									// 		{
									// 			$pricing_infos[] = str_replace('cnn0', 'cnn' . $i, $temp);
									// 		}
									// 		elseif($passenger_info_type == 'INF')
									// 		{
									// 			$pricing_infos[] = str_replace('inf0', 'inf' . $i, $temp);
									// 		}
									// 	}
									// }
									// break;
								}
							}

							foreach($airPricingSolution->children('common_v42_0', true) as $hostToken)
							{
								if(strcmp($hostToken->getName(), 'HostToken') == 0)
								{
									$host_tokens[] = $hostToken->asXML();
								}
							}				
							break;
						}
					}
				}
				elseif(strcmp($airPriceResult->getName(), 'AirItinerary') == 0)
				{
					$airItinerary = $airPriceResult;
					foreach($airItinerary->children('air', true) as $airSegment)
					{
						if(strcmp($airSegment->getName(), 'AirSegment') == 0)
						{
							$air_segments[] = $airSegment->asXML();
						}
					}
				}
			}

			$airPricingSolution = $airPricingSolution->asXML();

			if(empty($airPricingSolution))
			{
				throw new AirException("Invalid Reference ID.");
			}

			$ASreference_response = json_decode(file_get_contents(getcwd() . '/cache/air/reference_data/' . $refId . '_parsed_search.dat'), true);
			if(json_last_error() != JSON_ERROR_NONE)
			{
				throw new AirException("Something Went Wrong. Please Search Again.");
			}

			$isValidJourneyId 	= false;
			foreach($ASreference_response as $flight)
			{
				if(strcmp($flight['journey_ref_id'], $journeyRefId) == 0)
				{
					$isValidJourneyId 	= true;
					$connections 		= isset($flight['connection']) ? $flight['connection'] : [];
					break;
				}
			}
			if(!$isValidJourneyId)
			{
				throw new AirException("Invalid Journey Reference ID.");
			}

			$connection_string 	= "";
			foreach($connections as $connection)
			{
				$connection_string .= '<air:Connection SegmentIndex="'. $connection .'"/>';
			}
			$connection_string	.= '</air:AirPricingSolution>';

			$airPricingSolution = str_replace("</air:AirPricingSolution>", $connection_string, $airPricingSolution);

			$specific_seats = [];
			$ind 			= 0;
			$only_selected_seats = [];
			foreach($seats as $seat)
			{
				$tmp_seats 	= explode(',', $seat);
				$tmp_ind 	= 0;
				foreach($tmp_seats as $tmp_seat)
				{
					$tmp = explode(':', $tmp_seat);
					if(!isset($tmp[1]))
					{
						throw new AirException("Invalid Seats Format.");
					}

					$only_selected_seats[]	= $tmp[1];

					$specific_seats[$ind][$tmp_ind]['air_segment_ref_key'] 	= $tmp[0];
					$specific_seats[$ind][$tmp_ind]['seat_code'] 			= $tmp[1];
					$tmp_ind++;
				}
				$ind++;
			}

			// $SMreference_response = json_decode(file_get_contents(getcwd() . '/cache/air/reference_data/' . $refId . '_parsed_map.dat'), true);
			// if(json_last_error() != JSON_ERROR_NONE)
			// {
			// 	throw new AirException("Something Went Wrong. Please Search Again.");
			// }

			// $temp_xml = file_get_contents(getcwd() . '/cache/air/reference_data/' . $refId . '_raw_map.dat');
			// if(empty($temp_xml))
			// {
			// 	throw new AirException("Encoding Error.");
			// 	return false;
			// }

			// $temp_xml 	= simplexml_load_String($temp_xml);
			// $Results 	= $temp_xml->children('SOAP', true);

			// foreach($Results->children('SOAP', true) as $fault)
			// {
			// 	if(strcmp($fault->getName(), 'Fault') == 0)
			// 	{
			// 		throw new AirException("Error occurred request/response processing: " . $fault->__toString());
			// 		return false;
			// 	}
			// }
			// $Results 		= $Results->children('air', true);

			// $optional_services 	= [];
			// $break_this 		= false;

			// if(isset($SMreference_response['travler'][0]) && isset($SMreference_response['travler'][0]['seats']) && isset($SMreference_response['travler'][0]['seats']['row']))
			// {
			// 	foreach($SMreference_response['travler'][0]['seats']['row'] as $row)
			// 	{
			// 		if(isset($row['seats']) && count($row['seats']) > 0)
			// 		{
			// 			foreach($row['seats'] as $rsp_seat)
			// 			{
			// 				if(in_array($rsp_seat['seat_code'], $only_selected_seats) && $rsp_seat['paid'])
			// 				{
			// 					$break_this = false;

			// 					foreach($Results->children('air', true) as $optionalServices)
			// 					{
			// 						if((string) $optionalServices->getName() == 'OptionalServices')
			// 						{
			// 							foreach($optionalServices->children('air', true) as $optionalService)
			// 							{
			// 								if((string) $optionalService->getName() == 'OptionalService')
			// 								{
			// 									foreach($optionalService->attributes() as $key => $val)
			// 									{
			// 										if((string) $key == 'Key' && (string) $val == $rsp_seat['optional_service_ref_key'])
			// 										{
			// 											$optional_services[] 	= $optionalService->asXML();
			// 											$break_this 			= true;
			// 											break;
			// 										}
			// 									}
			// 									if($break_this)
			// 										break;
			// 								}
			// 							}
			// 						}
			// 						if($break_this)
			// 							break;
			// 					}
			// 				}
			// 			}
			// 		}
			// 	}
			// }
		}
		catch (AirException $e) 
		{
			$response['status'] = "error";
			$response['msg'] 	= $e->errorMessage();
			die(json_encode($response));
		}

		//Getting XML ready for API request
		ob_start();
			require getcwd() . DS . REQUEST_DIR . DS . AIR_CREATE_RESERVATION_REQUEST_FILE;
		$requestXML = ob_get_clean();
		//End

		require_once getcwd() . DS . "AirModels" . DS . "Reservation.php";
	}
	else
	{
		$specific_seats = [];
		$ind 			= 0;
		$only_selected_seats = [];
		foreach($seats as $seat)
		{
			$tmp_seats 	= explode(',', $seat);
			$tmp_ind 	= 0;
			foreach($tmp_seats as $tmp_seat)
			{
				$tmp = explode(':', $tmp_seat);
				if(!isset($tmp[1]))
				{
					throw new AirException("Invalid Seats Format.");
				}

				$only_selected_seats[]	= $tmp[1];

				$specific_seats[$ind][$tmp_ind]['air_segment_ref_key'] 	= $tmp[0];
				$specific_seats[$ind][$tmp_ind]['seat_code'] 			= $tmp[1];
				$tmp_ind++;
			}
			$ind++;
		}

		require_once getcwd() . DS . "AirModels" . DS . "SereneReservation.php";
	}

	try 
	{
		if($isSerene)
		{
			foreach($travelerTypes as $i => $traveler_type)
			{
				SereneReservation::$Passengers[$i] = ['traveler_type' => $traveler_type, 'prefix' => $prefixes[$i], 'firstname' => $firstnames[$i], 'lastname' => $lastnames[$i], 'gender' => isset($genders[$i]) ? (strtolower($genders[$i]) == 'female' ? 'F' : 'M') : null, 'age' => isset($ages[$i]) ? $ages[$i] : null, 'dob' => isset($dobs[$i]) ? $dobs[$i] : null, 'country' => isset($passenger_country[$i]) ? $passenger_country[$i] : null, 'nationality' => isset($nationality[$i]) ? $nationality[$i] : null, 'passport_no' => isset($passport_no[$i]) ? $passport_no[$i] : null, 'passport_expiry' => isset($passport_expiry[$i]) ? $passport_expiry[$i] : null, 'seats' => []];

				$c = 0;
				foreach($specific_seats[$i] as $seat)
				{
					SereneReservation::$Passengers[$i]['seats'][$c]['air_segment_ref_key']	= $seat['air_segment_ref_key'];
					SereneReservation::$Passengers[$i]['seats'][$c]['seat_code']			= $seat['seat_code'];
					$c++;
				}
			}

			SereneReservation::$PostalInfo = ['cnic' => $cnic, 'phone_number' => $phoneNumber, 'address' => $addressName, 'street' => $street, 'city' => $city, 'state' => $state, 'postal_code' => $postalCode, 'country' => $country, 'area_code' => $areaCode, 'country_code' => $countryCode, 'location' => $location, 'email' => $email];

			$data = SereneReservation::save($user_id, $refId, $journeyRefId);
		}
		else
		{
			Reservation::makeRequest($requestXML);
			$data 	= Reservation::parseResponse();

			if(!copy(getcwd() . '/cache/air/' . Reservation::getCacheFilename() . '_raw.dat', getcwd() . '/cache/air/reference_data/' . $refId . '_raw_reservation.dat') || !copy(getcwd() . '/cache/air/' . Reservation::getCacheFilename() . '_parsed.dat', getcwd() . '/cache/air/reference_data/' . $refId . '_parsed_reservation.dat'))
			{
				throw new AirException("Something Went Wrong. Please Try Again");
			}

			foreach($travelerTypes as $i => $traveler_type)
			{
				Reservation::$Passengers[$i] = ['traveler_type' => $traveler_type, 'prefix' => $prefixes[$i], 'firstname' => $firstnames[$i], 'lastname' => $lastnames[$i], 'gender' => isset($genders[$i]) ? (strtolower($genders[$i]) == 'female' ? 'F' : 'M') : null, 'age' => isset($ages[$i]) ? $ages[$i] : null, 'dob' => isset($dobs[$i]) ? $dobs[$i] : null, 'country' => isset($passenger_country[$i]) ? $passenger_country[$i] : null, 'nationality' => isset($nationality[$i]) ? $nationality[$i] : null, 'passport_no' => isset($passport_no[$i]) ? $passport_no[$i] : null, 'passport_expiry' => isset($passport_expiry[$i]) ? $passport_expiry[$i] : null, 'seats' => []];

				$c = 0;
				foreach($specific_seats[$i] as $seat)
				{
					Reservation::$Passengers[$i]['seats'][$c]['air_segment_ref_key']	= $seat['air_segment_ref_key'];
					Reservation::$Passengers[$i]['seats'][$c]['seat_code']			= $seat['seat_code'];
					$c++;
				}
			}

			Reservation::$PostalInfo = ['cnic' => $cnic, 'phone_number' => $phoneNumber, 'address' => $addressName, 'street' => $street, 'city' => $city, 'state' => $state, 'postal_code' => $postalCode, 'country' => $country, 'area_code' => $areaCode, 'country_code' => $countryCode, 'location' => $location, 'email' => $email];

			$data['booking_id'] 	= Reservation::save($user_id, $refId, $journeyRefId);
			$data['order_ref_id'] 	= Reservation::getOrderRefID();
		}

		$response['status'] = "success";
		$response['msg'] 	= count($data) . " matching results.";
		$response['data'] 	= $data;
	}
	catch (AirException $e) 
	{
		$response['status'] = "error";
		$response['msg'] 	= $e->errorMessage();
	}

	die(json_encode($response));
}
elseif(isset($_GET['confirm_booking']))
{
	require_once getcwd() . DS . "AirModels" . DS . "AirTicket.php";

	var_dump(AirTicket::process($_POST['order_ref_id']));

	die;

	header("Content-Type: application/json");

	$response 		= ['status' => '', 'msg' => '', 'data' => array()];

	$order_ref_id 	= isset($_POST['order_ref_id']) ? $_POST['order_ref_id'] : "";

	if(empty($order_ref_id) || !ctype_alnum($order_ref_id))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Order Ref ID is Required.'; 
		die(json_encode($response));
	}

	require_once getcwd() . DS . "AirModels" . DS . "AirTicket.php";

	try
	{
		if(!AirTicket::isPaid($order_ref_id))
		{
			$booking = AirTicket::getRecord();

			$air_reservation_locator_code 	= $booking['air_reservation_locator_code'];
			$air_pricing_info_keys 			= json_decode($booking['air_pricing_info_key'], true);

			if(json_last_error() != JSON_ERROR_NONE)
			{
				throw new AirException("Something Went Wrong. Please Try Again.");
			}

			//Getting XML ready for API request
			ob_start();
				require getcwd() . DS . REQUEST_DIR . DS . AIR_TICKETING_REQUEST_FILE;
			$requestXML = ob_get_clean();
			//End

			AirTicket::makeRequest($requestXML);
			$data 	= AirTicket::parseResponse();

			if(!copy(getcwd() . '/cache/air/' . AirTicket::getCacheFilename() . '_raw.dat', getcwd() . '/cache/air/reference_data/' . $order_ref_id . '_raw_ticket.dat') || !copy(getcwd() . '/cache/air/' . AirTicket::getCacheFilename() . '_parsed.dat', getcwd() . '/cache/air/reference_data/' . $order_ref_id . '_parsed_ticket.dat'))
			{
				throw new AirException("Something Went Wrong. Please Try Again");
			}

			$response['status'] = "success";
			$response['msg'] 	= count($data) . " matching results.";
			$response['data'] 	= $data;	
		}
		else
		{
			throw new AirException("Please Make a Payment First.");
		}
	}
	catch (AirException $e) 
	{
		$response['status'] = "error";
		$response['msg'] 	= $e->errorMessage();
	}

	die(json_encode($response));
}
elseif(isset($_GET['get_searched']))
{
	$response 		= ['status' => '', 'msg' => '', 'data' => array()];

	$refId 			= isset($_POST['ref_id']) ? $_POST['ref_id'] : "";

	if(empty($refId))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Reference ID Required.'; 
		die(json_encode($response));
	}
	elseif(!file_exists(getcwd() . '/cache/air/reference_data/' . $refId . '_raw_search.dat') || !file_exists(getcwd() . '/cache/air/reference_data/' . $refId . '_parsed_search.dat'))
	{
		$response['status']	= 'error'; 
		$response['msg']	= 'Invalid Reference ID.'; 
		die(json_encode($response));
	}

	try
	{
		$reference_response = json_decode(file_get_contents(getcwd() . '/cache/air/reference_data/' . $refId . '_parsed_search.dat'), true);
		if(json_last_error() != JSON_ERROR_NONE)
		{
			throw new AirException("Something Went Wrong. Please Search Again.");
		}
		$response['status'] = "success";
		$response['msg']	= count($reference_response) . " matching results.";
		$response['data']	= $reference_response;
		die(json_encode($response));
	}
	catch (AirException $e) 
	{
		$response['status'] = "error";
		$response['msg'] 	= $e->errorMessage();
		die(json_encode($response));
	}
}
elseif(isset($_GET['get_booking']))
{
	$response 		= ['status' => '', 'msg' => '', 'data' => array()];

	$booking_id 	= isset($_POST['booking_id']) ? $_POST['booking_id'] : '';

	if(empty($booking_id) || !is_numeric($booking_id))
	{
		$response['status'] = 'error';
		$response['msg']	= "Booking ID is Required";
		die(json_encode($response));
	}

	try
	{
		require_once getcwd() . DS . "AirModels" . DS . "AirBookingOrder.php";

		$response['status']	= 'success';
		$response['msg']	= 'Returning Record';
		$response['data']	= (new AirBookingOrder)->getBooking($booking_id);
	}
	catch(AirException $e)
	{
		$response['status'] = 'error';
		$response['msg']	= $e->getMessage();
	}

	die(json_encode($response));
}
elseif(isset($_GET['air_payment']))
{
    require_once('cls/paymentMethods.php');
    $PM 			= new paymentMethods();
    $orderRefNumber = preg_replace('/[^\da-z]/i', '', isset($_POST['order_ref']) ? cleanInput($_POST['order_ref']) : '');
    $paymentType 	= preg_replace('/[^\da-z]/i', '', isset($_POST['payment_type']) ? cleanInput($_POST['payment_type']) : '');
    $paymentMethod 	= preg_replace('/[^\da-z_]/i', '', isset($_POST['payment_method']) ? cleanInput($_POST['payment_method']) : '');
    $commission 	= (int) $_POST['air_comm'];
    $amount 		= $commissionAmount = 0; 
    $phone 			= $email = $pgUrl = $pgResponse = '';
    $promo_claim_id = (int) (isset($_POST['promo_claim_id']) ? $_POST['promo_claim_id'] : '');
    
    $stmt = DB::prepare("SELECT total_price, comission, airline, flight_from, flight_to, reservation_locator_code, 
        initial_departure_datetime, initial_departure_timezone, name, phone_number, email
        FROM `air_booking_order` WHERE `order_ref_id` = :id");
	$stmt->execute(['id' => $orderRefNumber]); 

	if(!$stmt->rowCount())
	{
		$err 	= $stmt->errorInfo(); 
		die('{"status":"failed","error":"Invalid Order Ref."}');
	}
	else
	{
	    $stmt->setFetchMode(PDO::FETCH_CLASS, 'stdClass');
		$order = $stmt->fetch();
		$amount = $order->total_price;
		$phone = $order->phone_number;
		$email = $order->email;
		
		if ($commission > 0)
		{
    		$commissionAmount = $amount * ($commission / 100);
    		$amount = $amount + $commissionAmount;
    		$order->total_price = $amount;
    		$order->comission = $commissionAmount;
    		
		    $Query = "UPDATE air_booking_order SET total_price = ".$amount.", comission = ".$commissionAmount.", ep_pay_method = '" . $paymentMethod . "' WHERE order_ref_id = :id";
		    $stmt = DB::prepare($Query);
		    $stmt->execute(['id' => $orderRefNumber]); 
		}

		if(!empty($promo_claim_id))
		{
			$promocode = "";
	        $promo_discount = 0;

	        require_once getcwd() . DS . "AirModels" . DS . "PromoCode.php";

	        $promo = PromoCode::getPromo($promo_claim_id, str_replace('+', '', $phone));

	        if(!empty($promo))
	        {
	        	$amount -= $promo['discount'];
	        	$order->total_price 	= $amount;
	        	$order->promo_discount 	= $promo['discount'];

	        	$Query = "UPDATE air_booking_order SET total_price = ".$amount.", promo_discount = ".$promo['discount']." WHERE order_ref_id = :id";
			    $stmt = DB::prepare($Query);
			    $stmt->execute(['id' => $orderRefNumber]);

	        	PromoCode::markClaimed($orderRefNumber, $promo_claim_id);
	        }
		}
	}

    if ($paymentType == "ep" && $paymentMethod != "")
    {
        $method = "Easy Pay";
        if ($paymentMethod == "CC_PAYMENT_METHOD")
            $pgUrl = "https://bookme.pk/easypay/".$orderRefNumber."/airline";
        else
            $pgResponse = $PM->esaypayPayment($paymentMethod, $orderRefNumber, $amount, str_replace('+92', '0', $phone), $email);
    }
    else if ($paymentType == "jc" && $paymentMethod != "")
    {
        $method = "Jazzcash";
    
        if ($paymentMethod == "CC")
            $pgUrl = "https://bookme.pk/jazzcash/".urlencode($orderRefNumber)."/airline";
        else
            $pgResponse = $PM->jazzcashPayment($paymentMethod, $orderRefNumber, $amount, str_replace('+92', '0', $phone), $email);
    }

    $Query = "UPDATE air_booking_order SET ep_pay_method = '" . $paymentMethod . "', payment_type = '" . $paymentType . "' WHERE order_ref_id = :id";
    $stmt = DB::prepare($Query);
    $stmt->execute(['id' => $orderRefNumber]); 

    $order->status = "success";
    $order->method = $method;
    $order->gateway_url = $pgUrl;
    $order->payment_response = $pgResponse;
    echo(json_encode($order));
    die;
}
elseif(isset($_GET['air_history']))
{
	$response = ['status' => '', 'msg' => '', 'data' => array()];

	$user_id = $_POST['user_id'] ?? '';

	if(!empty($user_id))
	{
		try
		{
			error_reporting(E_ALL);
			require_once getcwd() . DS . "AirModels" . DS . "AirBookingOrder.php";

			$response['status']	= 'success';
			$response['msg']	= 'Returning Record';
			$response['data']	= (new AirBookingOrder)->getHistory($user_id);
		}
		catch(AirException $e)
		{
			$response['status'] = 'error';
			$response['msg']	= $e->getMessage();
		}
	}
	else
	{
		$response['status'] = 'error';
		$response['msg'] 	= "User Required.";
	}

	die(json_encode($response));
}
