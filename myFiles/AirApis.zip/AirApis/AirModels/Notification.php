<?php

/**
 * @Author: Umar Hayat
 * @Date:   2019-09-17 11:06:56
 * @Last Modified by:   mailm
 * @Last Modified time: 2020-02-20 13:07:41
 */
 if(!class_exists('PHPMailer'))
 {  
    require_once('PHPMailer-master/class.phpmailer.php');
 }
    
class Notification
{
	private static function makeRequest($url)
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$server_output = curl_exec($ch);
		curl_close ($ch);

		return $server_output;
	}

	public static function sendSMS($to, $message)
	{
		if (substr($to, 0, 2) == '03')
			$to = "92" . substr($to, 1);
		else if (substr($to, 0, 2) == '92')
			$to = $to;
		else
			$to = "92" . $to;

		$message .= "\nDownload Bookme.pk app & get 100 Rs. Free: https://bookme.pk/u/rSKbM5";

		$url 	= "https://bookme.pk/sms/send.php?sms93003&smstxt=" . urlencode($message) . "&phone=" . $to;
		$url2 	= "https://bookme.pk/sms/send.php?sms93003&smstxt=" . urlencode($message) . "&phone=923316080120";

		$sent = self::makeRequest($url);
		$sent = self::makeRequest($url2);

		return $sent;
	}

	public static function sendEmail($to, $name, $subject, $body)
	{
		$mail = new PHPMailer();
		$mail->IsSMTP(); // telling the class to use SMTP
		$mail->SMTPSecure = 'ssl';
		$mail->SMTPDebug  = 0;                     // enables SMTP debug information (for testing)
											   // 1 = errors and messages
											   // 2 = messages only
		$mail->SMTPAuth   = true;                  // enable SMTP authentication
		$mail->Host       = "smtp.gmail.com"; // sets the SMTP server
		$mail->Port       = 465;                    // set the SMTP port for the GMAIL server
		$mail->Username   = "noreply@bookme.pk"; // SMTP account username
		$mail->Password   = "jkqbxirbnsetkuhj";        // SMTP account password

		$mail->SetFrom('noreply@bookme.pk', 'Bookme');
		//$mail->AddReplyTo("contact@bookme.pk","Bookme");
		$mail->Subject    = $subject;
		$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!";
		$mail->MsgHTML($body);
		$mail->AddAddress($to, $name);
		// $mail->AddAddress("mail.mrhayat@gmail.com", "Umar Hayat");
        
		return $mail->Send();
	}
}