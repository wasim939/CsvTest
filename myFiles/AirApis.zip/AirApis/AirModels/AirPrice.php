<?php

/**
 * @Author: Umar Hayat
 * @Date:   2019-08-02 16:27:20
 * @Last Modified by:   mailm
 * @Last Modified time: 2020-01-09 13:36:56
 */
require_once "AirModel.php";
require_once "Airport.php";

class AirPrice extends AirModel
{
	private static function getHostToken($node)
	{
		foreach($node->children('air', true) as $airPricingSolution)
		{
			if((string) $airPricingSolution->getName() == 'AirPricingSolution')
			{
				foreach($airPricingSolution->children('common_v42_0', true) as $hostToken)
				{
					if((string) $hostToken->getName() == 'HostToken')
					{
						foreach($hostToken->attributes() as $key => $val)
						{
							if((string) $key == 'Key')
							{
								return ['key' => (string)$val, 'host_token' => $hostToken->__toString()];
							}
						}
					}
				}
			}
		}
		return [];
	}

	private static function getHostTokenByKey($host_token_ref_key, $node)
	{
		foreach($node->children('air', true) as $airPriceResult)
		{
			if((string) $airPriceResult->getName() == 'AirPriceResult')
			{
				foreach($airPriceResult->children('air', true) as $airPricingSolution)
				{
					if((string) $airPricingSolution->getName() == 'AirPricingSolution')
					{
						foreach($airPricingSolution->children('common_v42_0', true) as $hostToken)
						{
							if((string) $hostToken->getName() == 'HostToken')
							{
								foreach($hostToken->attributes() as $key => $val)
								{
									if((string) $key == 'Key' && (string) $host_token_ref_key == $val)
									{
										return $hostToken->__toString();
									}
								}
							}
						}
					}
				}
			}
		}
	}

	private static function getBookingInfo($key, $airPriceNode)
	{
		$bookingInfoNodes = [];
		foreach($airPriceNode->children('air', true) as $airPriceResult)
		{		
			if((string) $airPriceResult->getName() == 'AirPriceResult')
			{			
				foreach($airPriceResult->children('air', true) as $airPricingSolution)
				{				
					if((string) $airPricingSolution->getName() == 'AirPricingSolution')
					{	
						foreach($airPricingSolution->children('air', true) as $airPricingInfo)
						{
							if((string) $airPricingInfo->getName() == 'AirPricingInfo')
							{
								foreach($airPricingInfo->children('air', true) as $bookingInfo)
								{
									if((string) $bookingInfo->getName() == 'BookingInfo')
									{
										foreach($bookingInfo->attributes() as $a => $b)
										{						
											if((string) $a == 'SegmentRef')
											{							
												if((string) $b == $key)
												{
													$bookingInfoNodes[] = $bookingInfo;
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		return $bookingInfoNodes;
	}

	public static function parseResponse($extra_info = [])
	{
		if(!empty(self::$responseArray))
			return self::$responseArray;

		if(empty(self::$rawResponse))
		{
			throw new AirException("Response from server is empty.");
		}

		$xml 	= simplexml_load_String(self::$rawResponse, null, null, 'SOAP', true);	
		
		if(empty($xml))
		{
			throw new AirException("Encoding Error.");
			return false;
		}

		$Results = $xml->children('SOAP',true);
		foreach($Results->children('SOAP',true) as $fault)
		{
			if((string) $fault->getName() == 'Fault')
			{
				throw new AirException("Error occurred request/response processing: " . $fault->__toString());
				return false;
			}
		}

		$count 	= -1;
		self::$responseArray['message'] 	= array();
		self::$responseArray['air_segment'] = array();

		foreach($Results->children('air', true) as $airPriceRsp)
		{
			foreach($airPriceRsp->children('common_v42_0', true) as $child)
			{
				if((string) $child->getName() == 'ResponseMessage')
				{
					self::$responseArray['message'][] 	= $child->__toString();
				}
			}

			foreach($airPriceRsp->children('air', true) as $child)
			{
				if((string) $child->getName() == 'AirItinerary')
				{
					foreach($child->children('air', true) as $airSegment)
					{
						if((string) $airSegment->getName() == 'AirSegment')
						{
							$count++;
							self::$responseArray['air_segment'][$count]['baggage_allowance'] = [];
							foreach($airSegment->attributes() as $key => $val)
							{
								if((string) $key == "Key")
								{
									self::$responseArray['air_segment'][$count]['air_segment_ref_key']	= (string) $val;
									self::$responseArray['air_segment'][$count]['host_token'] = array();

									$bookingInfos 	= self::getBookingInfo((string) $val, $airPriceRsp);
									$bcount 		= 0;

									foreach($bookingInfos as $bookingInfo)
									{
										foreach($bookingInfo->attributes() as $bKey => $bVal)
										{
											// if((string) $bKey == 'FareInfoRef')
											// {

											// }
											// elseif((string) $bKey == 'SegmentRef')
											// {

											// }
											// else
											if((string) $bKey == 'HostTokenRef')
											{
												self::$responseArray['air_segment'][$count]['host_token']/*[$bcount]*/['key']	= (string) $bVal;
												self::$responseArray['air_segment'][$count]['host_token']/*[$bcount]*/['token']	= self::getHostTokenByKey($bVal, $airPriceRsp);
												break;
											}
										}
										$bcount++;
									}
								}
								elseif((string) $key == "Group")
								{
									self::$responseArray['air_segment'][$count]['group']	= (string) $val;
								}
								elseif((string) $key == "Carrier")
								{											
									$tempAirline 	= (string) $val;
									self::$responseArray['air_segment'][$count]['carrier']	= $tempAirline;
									self::$responseArray['air_segment'][$count]['airline']	= self::airlineByCode($tempAirline);
									self::$responseArray['air_segment'][$count]['airline_logo']	= "https://bookme.pk/images/airlines/". $tempAirline .".svg";
								}
								elseif((string) $key == "FlightNumber")
								{
									$val = (string) $val;
									self::$responseArray['air_segment'][$count]['flight']	= $tempAirline . $val;
									self::$responseArray['air_segment'][$count]['flight_number']	= $val;
								}
								elseif((string) $key == "ProviderCode")
								{									
									self::$responseArray['air_segment'][$count]['provider_code']	= (string) $val;			
								}
								elseif((string) $key == "Origin")
								{											
									self::$responseArray['air_segment'][$count]['from']	= (string) $val;
									self::$responseArray['air_segment'][$count]['from_airport']	= Airport::getAirportNameByCode((string) $val);
								}
								elseif((string) $key == "Destination")
								{											
									self::$responseArray['air_segment'][$count]['to']	= (string) $val;
									self::$responseArray['air_segment'][$count]['to_airport']	= Airport::getAirportNameByCode((string) $val);
								}
								elseif((string) $key == "DepartureTime")
								{											
									self::$responseArray['air_segment'][$count]['depart']	= (string) $val;	
								}
								elseif((string) $key == "ArrivalTime")
								{											
									self::$responseArray['air_segment'][$count]['arrival']	= (string) $val;	
								}
								elseif((string) $key == "FlightTime")
								{											
									self::$responseArray['air_segment'][$count]['flight_time']	= (string) $val;	
								}
								elseif((string) $key == "TravelTime")
								{											
									self::$responseArray['air_segment'][$count]['travel_time']	= (string) $val;	
								}
								elseif((string) $key == "Distance")
								{											
									self::$responseArray['air_segment'][$count]['distance']	= (string) $val;	
								}
								elseif((string) $key == "ClassOfService")
								{											
									self::$responseArray['air_segment'][$count]['class']	= (string) $val;	
								}
								elseif((string) $key == "Equipment")
								{											
									self::$responseArray['air_segment'][$count]['plane']	 = (string) $val;	
									self::$responseArray['air_segment'][$count]['equipment'] =  self::planeByCode($val);	
								}
								elseif((string) $key == "ChangeOfPlane")
								{											
									self::$responseArray['air_segment'][$count]['change_of_plane']	= ((string) $val == "true" ? true : false);	
								}
								elseif((string) $key == "OptionalServicesIndicator")
								{											
									self::$responseArray['air_segment'][$count]['optional_services_indicator']	= ((string) $val == "true" ? true : false);	
								}
								elseif((string) $key == "AvailabilitySource")
								{											
									self::$responseArray['air_segment'][$count]['availability_source']	= (string) $val;	
								}
								elseif((string) $key == "AvailabilityDisplayType")
								{											
									self::$responseArray['air_segment'][$count]['availability_display_type']	= (string) $val;	
								}
							}
						}
					}
				}
				elseif((string) $child->getName() == 'AirPriceResult')
				{
					foreach($child->children('air', true) as $airSegment)
					{
						if((string) $airSegment->getName() == 'AirPricingSolution')
						{
						    if(isset(self::$responseArray['fare']) && !empty(self::$responseArray['fare']))
						        continue;
							self::$responseArray['fare'] = [];
							foreach($airSegment->attributes() as $key => $val)
							{
								if((string) $key == "TotalPrice")
								{
									self::$responseArray['fare']['total_price'] = (string) $val;
								}
								elseif((string) $key == "BasePrice")
								{
									self::$responseArray['fare']['base_price'] = (string) $val;
								}
								elseif((string) $key == "ApproximateTotalPrice")
								{
									self::$responseArray['fare']['approx_total_price'] = (string) $val;
								}
								elseif((string) $key == "ApproximateBasePrice")
								{
									self::$responseArray['fare']['approx_base_price'] = (string) $val;
								}
								elseif((string) $key == "EquivalentBasePrice")
								{
									self::$responseArray['fare']['equivalent_base_price'] = (string) $val;
								}
								elseif((string) $key == "Taxes")
								{
									self::$responseArray['fare']['taxes'] = (string) $val;
								}
								elseif((string) $key == "Fees")
								{
									self::$responseArray['fare']['fees'] = (string) $val;
								}
								elseif((string) $key == "ApproximateTaxes")
								{
									self::$responseArray['fare']['approx_taxes'] = (string) $val;
								}
							}
							
							self::$responseArray['air_pricing_info_key'] = [];
							self::$responseArray['refund'] 				 = ['is_refundable' => 'N/A', 'change_penalty' => 'N/A', 'cancel_penalty' => 'N/A'];

							foreach($airSegment->children('air', true) as $airPricingInfo)
							{
								if((string) $airPricingInfo->getName() == 'AirPricingInfo')
								{
									foreach($airPricingInfo->attributes() as $key => $val)
									{
										if((string) $key == "Key")
										{
											self::$responseArray['air_pricing_info_key'][] = (string) $val;
										}
										elseif((string) $key == "Refundable")
										{
											self::$responseArray['refund']['is_refundable'] = (string) $val == 'true' ? true : false;
										}
									}

									foreach($airPricingInfo->children('air', true) as $childNode)
									{	
										if((string) $childNode->getName() == 'ChangePenalty')
										{
											foreach($childNode->children('air', true) as $changePenalty)
											{
												if((string) $changePenalty->getName() == 'Amount')
												{
													self::$responseArray['refund']['change_penalty'] = (string) $changePenalty;
												}
											}
										}
										elseif((string) $childNode->getName() == 'CancelPenalty')
										{
											foreach($childNode->children('air', true) as $cancelPenalty)
											{
												if((string) $cancelPenalty->getName() == 'Amount')
												{
													self::$responseArray['refund']['cancel_penalty'] = (string) $cancelPenalty;
												}
											}
										}
										elseif((string) $childNode->getName() == 'BaggageAllowances')
										{
											$baggage_count = 0;
											foreach($childNode->children('air', true) as $baggageAllowanceInfo)
											{
												if((string) $baggageAllowanceInfo->getName() == 'BaggageAllowanceInfo')
												{
													foreach($baggageAllowanceInfo->children('air', true) as $textInfo)
													{
														if((string) $textInfo->getName() == 'TextInfo')
														{
															foreach($textInfo->children('air', true) as $text)
															{
																if((string) $text->getName() == 'Text')
																{
																	if(!in_array((string) $text, self::$responseArray['air_segment'][$baggage_count]['baggage_allowance']))
																		self::$responseArray['air_segment'][$baggage_count]['baggage_allowance'][] = (string) $text;
																}
															}
															$baggage_count++;
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
					// $host_token = self::getHostToken($child);
					// if(count($host_token) > 0)
					// {
					// 	self::$responseArray['host']['key'] 	= $host_token['key'];
					// 	self::$responseArray['host']['token'] 	= $host_token['host_token'];
					// }
					// else
					// {
					// 	throw new AirException("Host Token Not Found.");
					// }
				}
			}
		}

		if(isset($extra_info['carrier']))
		{
			$extra_info['airline_logo'] = "https://bookme.pk/images/airlines/". $extra_info['carrier'] .".svg";
		}

		self::$responseArray = array_merge(self::$responseArray, $extra_info);

		file_put_contents(getcwd() . '/cache/air/' . self::$cacheFile . '_parsed.dat', json_encode(self::$responseArray));

		return self::$responseArray;
	}
}