<?php

/**
 * @Author: Umar Hayat
 * @Date:   2019-10-22 05:05:41
 * @Last Modified by:   Muhammad Umar Hayat
 * @Last Modified time: 2019-11-25 14:55:36
 */
require_once "AirModel.php";
require_once "AirException.php";

class AirCancelRequest extends AirModel
{
	public static function cancelUniversalRecord($universal_locator_code)
	{
		if(empty($universal_locator_code))
		{
			throw new AirException("Universal Locator Code Required.");			
		}

		//Getting XML ready for API request
		ob_start();
			require dirname(__FILE__) . '/../xml_requests/air_cancel_req.php';
		$requestXML = ob_get_clean();
		//End

		try
		{
			self::makeRequest($requestXML);
			return true;
		}
		catch(AirException $e)
		{
			throw new AirException($e->getMessage());			
		}
	}
	
	public static function makeRequest($request)
	{
		self::$responseArray 	= [];

		$auth 		= base64_encode(self::TP_USERNAME . ':' . self::TP_PASSWORD); 
		try
		{
			$soap_do 	= curl_init(self::TP_URL);
			$header 	= array(
				"Content-Type: text/xml;charset=UTF-8", 
				"Accept: gzip,deflate", 
				"Cache-Control: no-cache", 
				"Pragma: no-cache", 
				"SOAPAction: \"\"",
				"Authorization: Basic $auth", 
				"Content-length: " . strlen($request),
			); 

			//curl_setopt($soap_do, CURLOPT_CONNECTTIMEOUT, 30); 
			//curl_setopt($soap_do, CURLOPT_TIMEOUT, 30); 
			curl_setopt($soap_do, CURLOPT_SSL_VERIFYPEER, false); 
			curl_setopt($soap_do, CURLOPT_SSL_VERIFYHOST, false); 
			curl_setopt($soap_do, CURLOPT_POST, true ); 
			curl_setopt($soap_do, CURLOPT_POSTFIELDS, $request); 
			curl_setopt($soap_do, CURLOPT_HTTPHEADER, $header); 
			curl_setopt($soap_do, CURLOPT_RETURNTRANSFER, true);
			self::$rawResponse = curl_exec($soap_do);

			if (curl_errno($soap_do)) 
			{
				throw new AirException("Unable to make request to server. Error: " . curl_errno($soap_do));
			}

			curl_close($soap_do);
		}
		catch(Exception $e)
		{
			throw new AirException("Unable to make request to server.");
		}

		return self::$rawResponse;
	}
}