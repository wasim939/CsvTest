<?php

/**
 * @Author: Umar Hayat
 * @Date:   2019-09-14 17:38:25
 * @Last Modified by:   Umar Hayat
 * @Last Modified time: 2019-09-14 17:39:01
 */

require_once "AirException.php";
require_once "DB.php";

class AirSeats extends DB
{

}