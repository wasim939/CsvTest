<?php 
if(!defined('ENVIROMENT'))
	die("Enviroment Not Defined.");

/**
 * @Author: Umar Hayat
 * @Date:   2019-07-31 12:31:42
 * @Last Modified by:   Umar Hayat
 * @Last Modified time: 2019-09-17 15:26:23
 */

abstract class DB
{
	private static $connection = null;

	private static $host 		= DB_HOST;
	private static $dbUsername 	= DB_USERNAME;
	private static $dbPassword 	= DB_PASSWORD;
	private static $dbName 		= DB_NAME;

	public static function getConnection()
	{
		if(is_null(self::$connection))
		{
			try 
			{
			    self::$connection = new PDO("mysql:host=". self::$host .";dbname=". self::$dbName .";charset=utf8", self::$dbUsername, self::$dbPassword);
			    // set the PDO error mode to exception
			    self::$connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
			    self::$connection->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            	self::$connection->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
			}
			catch(PDOException $e)
			{
			    die("Connection failed: " . $e->getMessage());
			}
		}

		return self::$connection;
	}

	public static function prepare($query)
	{
		return self::getConnection()->prepare($query);
	}

	public static function getLastInsertId()
	{
		return self::getConnection()->lastInsertId();
	}

	protected function getNewRefID()
	{
		$microtime 	= microtime();
        $temp 		= explode(" ", $microtime);
        $UID 		= substr($temp[0], 2, 6);
		$query 		= "UPDATE `ep_ref_id` SET `last_ref_id` = `last_ref_id` + 1 LIMIT 1";
		$stmt 		= self::prepare($query);
		$stmt->execute();
		$query 		= "SELECT `last_ref_id` FROM `ep_ref_id`";
		$stmt 		= self::prepare($query);
		$stmt->execute();
		return $stmt->fetch()['last_ref_id'];
	}
}