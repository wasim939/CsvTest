<?php

/**
 * @Author: Umar Hayat
 * @Date:   2019-09-14 17:38:10
 * @Last Modified by:   Umar Hayat
 * @Last Modified time: 2019-09-14 17:39:09
 */

require_once "AirException.php";
require_once "DB.php";

class AirSegment extends DB
{

}