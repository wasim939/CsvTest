<?php

/**
 * @Author: Umar Hayat
 * @Date:   2019-08-21 15:51:16
 * @Last Modified by:   Umar Hayat
 * @Last Modified time: 2019-08-21 15:58:28
 */
require_once "AirException.php";
require_once "DB.php";

class Airline extends DB
{
	public static function get($airline_code = 0)
	{
		try
		{
			$conds 	= [];
			if(!empty($airline_code))
			{
				$query 			= "SELECT * FROM `airlines` WHERE `active` = 'Y' AND `iata` = :iata LIMIT 1";
				$conds['iata'] 	= $airline_code;
			}
			else
			{
				$query = "SELECT * FROM `airlines` WHERE `active` = 'Y'";
			}
			$stmt = self::prepare($query);
			$stmt->execute($conds);

			return $stmt->fetchAll();
		}
		catch(PDOException $e)
		{
			throw new AirException("Database Error: " . $e->getMessage());
		}
	}
}

