<?php

/**
 * @Author: Umar Hayat
 * @Date:   2019-09-15 04:50:02
 * @Last Modified by:   mailm
 * @Last Modified time: 2020-02-16 16:44:48
 */

require_once "AirModel.php";
require_once "AirException.php";
require_once "DB.php";
require_once "Notification.php";

class AirTicket extends AirModel
{
	private static $record 		= null;
	private static $airSegments = null;
	private static $responseCode = null;
	private static $responseMessage = null;
	private static $ticketNumbers 	= null;

	public static function process($order_ref_id)
	{
		$query = "SELECT * FROM `air_booking_order` WHERE `order_ref_id` = :order_ref_id AND enviroment = 'production' LIMIT 1;";
		$conds 	= ['order_ref_id' => $order_ref_id];

		$stmt 	= DB::prepare($query);
		$stmt->execute($conds);

		if($stmt->rowCount() > 0)
		{
			self::$record = $stmt->fetch();

			$query 	= "SELECT * FROM `air_segment` WHERE `air_booking_order_id` = :air_booking_order_id;";
			$conds	= ['air_booking_order_id' => self::$record['id']];

			$stmt 	= DB::prepare($query);
			$stmt->execute($conds);

			self::$airSegments = $stmt->fetchAll();

			if(self::$record['carrier'] == 'ER' && self::$record['payment'] == 'unpaid')
			{
				Notification::sendSMS('+923316080120', $order_ref_id . ": SereneAir Order Got Paid. Please Issue Ticket and Tell Umar.");
				Notification::sendSMS('+923334705208', $order_ref_id . ": SereneAir Order Got Paid. Please Issue Ticket and Tell Umar.");
				Notification::sendSMS('+923059619439', $order_ref_id . ": SereneAir Order Got Paid. Please Issue Ticket and Tell Umar.");

				self::$responseArray = ['status' => "success", 'message' => "A CSR needs to manually issue ticket from Serene Portal."];
			}
			elseif(self::$record['payment'] == 'paid' && !empty(self::$record['ticket_numbers']))
			{
				self::$ticketNumbers = json_decode(self::$record['ticket_numbers'], true);
				
				self::sendNotification();

				self::$responseArray = ['status' => "success", 'message' => "Booking Already Confirmed. A Confirmation SMS & Email Has Been Sent."];
			}
			else
			{
				$air_reservation_locator_code 	= self::$record['air_reservation_locator_code'];
				$air_pricing_info_keys 			= json_decode(self::$record['air_pricing_info_key'], true);

				//Getting XML ready for API request
				ob_start();
					require dirname(__FILE__) . "/../xml_requests/air_ticketing_req.php";
				$requestXML = ob_get_clean();
				//End

				try 
				{
					self::makeRequest($requestXML);

					if(self::parseResponse())
					{
						$query = "UPDATE `air_booking_order` SET `payment` = 'paid', `ticket_numbers` = :ticket_numbers, `booking_status` = 'ticket_issued' WHERE `id` = :id";
						$conds = ['ticket_numbers' => json_encode(self::$ticketNumbers), 'id' => self::$record['id']];

						$stmt  = DB::prepare($query);
						$stmt->execute($conds);

						self::sendNotification();

						self::$responseArray = ['status' => "success", 'message' => "Booking Confirmed. A Confirmation SMS & Email Has Been Sent."];
					}
					else
					{
						$query = "UPDATE `air_booking_order` SET `travelport_response` = :travelport_response, `travelport_response_code` = :travelport_response_code WHERE `id` = :id";
						$conds = ['travelport_response' => self::$responseMessage, 'travelport_response_code' => self::$responseCode, 'id'	=> self::$record['id']];

						$stmt  = DB::prepare($query);
						$stmt->execute($conds);

						Notification::sendSMS('+923316080120', $order_ref_id . ": " . self::$responseMessage);

						self::$responseArray = ['status' => "error", 'message' => "Error: " . self::$responseMessage];
					}
				}
				catch(AirException $e)
				{
					self::$responseArray = ['status' => "error", 'message' => $e->getMessage()];
				}
			}
		}
		return self::$responseArray;
	}

	public static function getSeatsBySegment($air_booking_order_id, $air_segment_id)
	{
		$query 	= "SELECT GROUP_CONCAT(`seat_code`, ', ') AS seats FROM `air_seats` WHERE `air_booking_order_id` = :air_booking_order_id AND `air_segment_id` = :air_segment_id LIMIT 1";
		$conds	= ['air_booking_order_id' => $air_booking_order_id, 'air_segment_id' => $air_segment_id];

		$stmt = DB::prepare($query);
		$stmt->execute($conds);

		if($stmt->rowCount() > 0)
		{
			$temp = $stmt->fetch();

			return $temp['seats'];
		}

		return '';
	}

	public static function parseResponse()
	{
		if(!empty(self::$responseArray))
			return self::$responseArray;

		if(empty(self::$rawResponse))
		{
			throw new AirException("Response from server is empty.");
		}

		$xml 	= simplexml_load_String(self::$rawResponse, null, null, 'SOAP', true);	
		
		if(empty($xml))
		{
			throw new AirException("Encoding Error.");
			return false;
		}

		$Results = $xml->children('SOAP',true);
		foreach($Results->children('SOAP',true) as $fault)
		{
			if(strcmp($fault->getName(), 'Fault') == 0)
			{
				throw new AirException("Error occurred request/response processing: " . $fault->__toString());
				return false;
			}
		}

		foreach($Results->children('air', true) as $airTicketingRsp)
		{
			if(strcmp($airTicketingRsp->getName(), 'AirTicketingRsp') == 0)
			{
				foreach($airTicketingRsp->children('air', true) as $child)
				{
					if(strcmp($child->getName(), 'TicketFailureInfo') == 0)
					{
						foreach($child->attributes() as $key => $val)
						{
							if(strcmp($key, 'Code') == 0)
							{
								self::$responseCode = (string) $val;
							}
							elseif(strcmp($key, 'Message') == 0)
							{
								self::$responseMessage = (string) $val;
							}
						}
						return false;
					}
					elseif(strcmp($child->getName(), 'ETR') == 0)
					{
						foreach($child->children('air', true) as $ticket)
						{
							if(strcmp($ticket->getName(), 'Ticket') == 0)
							{
								foreach($ticket->attributes() as $key => $val)
								{
									if(strcmp($key, 'TicketNumber') == 0)
									{
										self::$ticketNumbers[]	= (string) $val;
									}
								}
							}
						}
					}
				}
			}
		}

		return true;
	}

	private static function sendNotification()
	{
		$message = "Dear " . self::$record['name'] . ",\nYour " . (self::$record['trip_type'] == 'one_way' ? 'one way' : (self::$record['trip_type'] == 'multi_city' ? 'multi-city' : 'return')) . " ticket from " . self::$record['flight_from'] . " to " . self::$record['flight_to'] . " is confirmed.\nPNR: " . self::$record['reservation_locator_code'] . "\nTicket #: " . implode(", ", self::$ticketNumbers);
		Notification::sendSMS(self::$record['phone_number'], $message);

		ob_start();
			require_once "Airport.php";
			require dirname(__FILE__) . "/../xml_requests/air_ticket_email.php";
		$email_body = ob_get_clean();

		Notification::sendEmail(self::$record['email'], self::$record['name'], "Air Ticket Confirmation", $email_body);
	}
}