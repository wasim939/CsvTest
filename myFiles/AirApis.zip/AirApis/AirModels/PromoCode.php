<?php

/**
 * @Author: Muhammad Umar Hayat
 * @Date:   2019-11-15 02:44:17
 * @Last Modified by:   Muhammad Umar Hayat
 * @Last Modified time: 2019-11-15 02:54:03
 */
require_once "AirException.php";
require_once "DB.php";

class PromoCode extends DB
{
	public static function getPromo($claim_id, $phone)
	{
		try
		{
			$conds 	= [];

			$query = "SELECT code, discount FROM promocode_users WHERE order_id = '' AND id = :claim_id AND phone = :phone AND claimed = 0 LIMIT 1";
			$conds['claim_id'] 	= $claim_id;
			$conds['phone'] 	= $phone;

			$stmt = self::prepare($query);
			$stmt->execute($conds);

			return $stmt->fetch();
		}
		catch(PDOException $e)
		{
			throw new AirException("Database Error: " . $e->getMessage());
		}
	}

	public static function markClaimed($order_id, $claim_id)
	{
		try
		{
			$conds 	= [];

			$query = "UPDATE promocode_users SET order_id = :order_id, claimed = 1 WHERE id = :claim_id";
			$conds['claim_id'] 	= $claim_id;
			$conds['order_id'] 	= $order_id;

			$stmt = self::prepare($query);
			$stmt->execute($conds);

			return true;
		}
		catch(PDOException $e)
		{
			throw new AirException("Database Error: " . $e->getMessage());
		}
	}
}