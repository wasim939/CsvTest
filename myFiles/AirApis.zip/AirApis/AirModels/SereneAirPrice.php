<?php

/**
 * @Author: Umar Hayat
 * @Date:   2019-08-02 16:27:20
 * @Last Modified by:   mailm
 * @Last Modified time: 2020-01-30 20:30:17
 */
require_once "AirModel.php";
require_once "Airport.php";

class SereneAirPrice extends AirModel
{
	public static function makeRequest($request)
	{
		self::$cacheFile = md5(json_encode($request));

		file_put_contents(getcwd() . '/cache/air/' . self::$cacheFile . '_request.dat', json_encode($request));

		self::$responseArray = ['message' => [], 'air_segment' => [], 'fare' => [], 'air_pricing_info_key' => [], 'refund' => []];

		$count = 0;
		for($i = 0; $i < count($request['outbound_route']) - 1; $i++)
		{
			self::$responseArray['air_segment'][$count] = []; 
			self::setAirSegmentValues($count, $request['outbound_route'][$i]);
			$count++;
		}

		if(isset($request['inbound_route']))
		{
			for($i = 0; $i < count($request['inbound_route']) - 1; $i++)
			{
				self::$responseArray['air_segment'][$count] = []; 
				self::setAirSegmentValues($count, $request['inbound_route'][$i]);
				$count++;
			}
		}

		self::setPriceValues($request['approx_total_price']);

		self::$responseArray['refund'] = array('is_refundable' => true, 'change_penalty' => 'N/A', 'cancel_penalty' => 'N/A');

		self::setOtherInfo($request);

		file_put_contents(getcwd() . '/cache/air/' . self::$cacheFile . '_raw.dat', json_encode(self::$responseArray));
		file_put_contents(getcwd() . '/cache/air/' . self::$cacheFile . '_parsed.dat', json_encode(self::$responseArray));

		return self::$responseArray;
	}

	private static function setAirSegmentValues($count, $input)
	{
		self::$responseArray['air_segment'][$count]['baggage_allowance'] = ['32K'];
		self::$responseArray['air_segment'][$count]['air_segment_ref_key'] = 'N/A';
		self::$responseArray['air_segment'][$count]['host_token'] = ['key' => '', 'token' => ''];
		self::$responseArray['air_segment'][$count]['group'] 		= $input['group'];
		self::$responseArray['air_segment'][$count]['carrier'] 		= $input['carrier'];
		self::$responseArray['air_segment'][$count]['airline'] 		= $input['airline'];
		self::$responseArray['air_segment'][$count]['airline_logo'] = $input['airline_logo'];
		self::$responseArray['air_segment'][$count]['flight'] 		= $input['flight'];
		self::$responseArray['air_segment'][$count]['flight_number']= 'N/A';
		self::$responseArray['air_segment'][$count]['provider_code']= 'N/A';
		self::$responseArray['air_segment'][$count]['from'] 		= $input['from'];
		self::$responseArray['air_segment'][$count]['from_airport'] = Airport::getAirportNameByCode($input['from']);
		self::$responseArray['air_segment'][$count]['to'] 			= $input['to'];
		self::$responseArray['air_segment'][$count]['to_airport'] 	= Airport::getAirportNameByCode($input['to']);
		self::$responseArray['air_segment'][$count]['depart'] 		= $input['depart'];
		self::$responseArray['air_segment'][$count]['arrival'] 		=  $input['arrival'];
		self::$responseArray['air_segment'][$count]['flight_time'] 	=  $input['flight_time'];
		self::$responseArray['air_segment'][$count]['travel_time'] 	=  $input['travel_time'];
		self::$responseArray['air_segment'][$count]['distance'] 	= 'N/A';
		self::$responseArray['air_segment'][$count]['class'] 		= 'N/A';
		self::$responseArray['air_segment'][$count]['plane'] 		= 'N/A';
		self::$responseArray['air_segment'][$count]['equipment'] 	= 'N/A';
		self::$responseArray['air_segment'][$count]['change_of_plane'] 		= 'N/A';
		self::$responseArray['air_segment'][$count]['optional_services_indicator'] = 'N/A';
		self::$responseArray['air_segment'][$count]['availability_source'] 			= 'N/A';
		self::$responseArray['air_segment'][$count]['availability_display_type'] 	= 'N/A';
	}

	private static function setPriceValues($amount)
	{
		self::$responseArray['fare']['total_price'] 		= $amount;
		self::$responseArray['fare']['base_price'] 			= 'PKR0.0';
		self::$responseArray['fare']['approx_total_price'] 	= $amount;
		self::$responseArray['fare']['approx_base_price'] 	= 'PKR0.0';
		self::$responseArray['fare']['equivalent_base_price'] = 'PKR0.0';
		self::$responseArray['fare']['taxes'] 				= 'PKR0.0';
		self::$responseArray['fare']['fees'] 				= 'PKR0.0';
		self::$responseArray['fare']['approx_taxes'] 		= 'PKR0.0';
	}

	private static function setOtherInfo($request)
	{
		self::$responseArray['direction'] 		= $request['direction'];
		self::$responseArray['carrier'] 		= 'ER';
		self::$responseArray['airline'] 		= 'SereneAir';
		self::$responseArray['class'] 			= 'Economy';
		self::$responseArray['from'] 			= $request['outbound_route'][0]['from'] ?? 'N/A';
		self::$responseArray['to'] 				= $request['outbound_route'][count($request['outbound_route']) - 2]['to'] ?? 'N/A';
		self::$responseArray['no_of_adults'] 	= $request['no_of_adults'];
		self::$responseArray['no_of_children'] 	= $request['no_of_children'];
		self::$responseArray['no_of_infants'] 	= $request['no_of_infants'];
		self::$responseArray['airline_logo'] 	= 'https://bookme.pk/images/airlines/ER.svg';
	}
}