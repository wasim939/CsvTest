<?php

/**
 * @Author: Umar Hayat
 * @Date:   2019-09-14 17:37:03
 * @Last Modified by:   mailm
 * @Last Modified time: 2020-02-21 19:01:26
 */

require_once "AirException.php";
require_once "DB.php";
require_once "AirSegment.php";
require_once "AirPassenger.php";
require_once "AirSeats.php";
require_once "Notification.php";

class AirBookingOrder extends DB
{
	private $table 			= "air_booking_order";

	public $AirSegments 	= [];
	public $AirPassengers 	= [];
	public $AirSeats 		= [];

	private static $record 		= null;
	private static $airSegments = null;

	public function save()
	{
		$this->order_ref_id = "AIR" . str_pad($this->getNewRefID(), 12, "0", STR_PAD_LEFT);

		$query = "INSERT INTO `air_booking_order`(`user_id`, `order_ref_id`, `ref_id`, `journey_ref_id`, `trip_type`, `carrier`, `airline`, `flight_from`, `flight_to`, `class`, `approx_total_price`, `total_price`, `base_price`, `approx_base_price`, `taxes`, `approx_taxes`, `fees`, `currency`, `total_adults`, `total_children`, `total_infants`, `initial_departure_datetime`, `initial_departure_timezone`, `last_departure_datetime`, `last_departure_timezone`, `universal_locator_code`, `reservation_status`, `reservation_locator_code`, `owning_pcc`, `provider_reservation_info_key`, `air_reservation_locator_code`, `air_pricing_info_key`, `status`, `service_status`, `name`, `cnic`, `phone_number`, `address`, `street`, `city`, `state`, `postal_code`, `country`, `area_code`, `country_code`, `location`, `email`, `api_key`, `payment`, `enviroment`, `created_at`) VALUES (:user_id, :order_ref_id, :ref_id, :journey_ref_id, :trip_type, :carrier, :airline, :flight_from, :flight_to, :class, :approx_total_price, :total_price, :base_price, :approx_base_price, :taxes, :approx_taxes, :fees, :currency, :total_adults, :total_children, :total_infants, :initial_departure_datetime, :initial_departure_timezone, :last_departure_datetime, :last_departure_timezone, :universal_locator_code, :reservation_status, :reservation_locator_code, :owning_pcc, :provider_reservation_info_key, :air_reservation_locator_code, :air_pricing_info_key, :status, :service_status, :name, :cnic, :phone_number, :address, :street, :city, :state, :postal_code, :country, :area_code, :country_code, :location, :email, :api_key, :payment, :enviroment, :created_at);";

		$data 	= [];
		foreach(get_object_vars($this) as $name => $value)
		{
			if(in_array($name, ['table', 'AirSegments', 'AirPassengers', 'AirSeats']))
				continue;

			$data[$name] = $value;
		}

		try
		{
			$stmt = $this->prepare($query);
			$stmt->execute($data);
			$air_booking_order_id = $this->getLastInsertId();

			$savedAirSegments = [];

			$query = "INSERT INTO `air_segment`(`air_booking_order_id`, `air_segment_ref_key`, `air_group`, `carrier`, `airline`, `flight`, `flight_number`, `provider_code`, `travel_from`, `travel_to`, `departure_datetime`, `departure_timezone`, `arrival_datetime`, `arrival_timezone`, `flight_time`, `travel_time`, `distance`, `class`, `plane`, `equipment`, `change_of_plane`, `optional_services_indicator`, `availability_display_type`) VALUES (:air_booking_order_id, :air_segment_ref_key, :air_group, :carrier, :airline, :flight, :flight_number, :provider_code, :travel_from, :travel_to, :departure_datetime, :departure_timezone, :arrival_datetime, :arrival_timezone, :flight_time, :travel_time, :distance, :class, :plane, :equipment, :change_of_plane, :optional_services_indicator, :availability_display_type);";

			$stmt = $this->prepare($query);
			foreach($this->AirSegments as $air_segment)
			{
				$data = ['air_booking_order_id' => $air_booking_order_id];
				foreach(get_object_vars($air_segment) as $name => $value)
				{
					if(in_array($name, []))
						continue;

					$data[$name] = $value;
				}

				$stmt->execute($data);

				$saved_air_segments[$data['air_segment_ref_key']] = $this->getLastInsertId();
			}

			$query = "INSERT INTO `air_passenger`(`air_booking_order_id`, `traveler_type`, `prefix`, `firstname`, `lastname`, `gender`, `age`, `dob`, `country`, `nationality`, `passport_no`, `passport_expiry`) VALUES (:air_booking_order_id, :traveler_type, :prefix, :firstname, :lastname, :gender, :age, :dob, :country, :nationality, :passport_no, :passport_expiry);";
			$stmt = $this->prepare($query);

			$seat_query = "INSERT INTO `air_seats`(`air_booking_order_id`, `air_segment_id`, `air_passenger_id`, `seat_code`) VALUES (:air_booking_order_id, :air_segment_id, :air_passenger_id, :seat_code)";
			$stmt2 = $this->prepare($seat_query);

			foreach($this->AirPassengers as $passenger)
			{
				$data = ['air_booking_order_id' => $air_booking_order_id];
				foreach(get_object_vars($passenger) as $name => $value)
				{
					if(in_array($name, ['seats']))
						continue;

					$data[$name] = $value;
				}

				$stmt->execute($data);

				$data = ['air_booking_order_id' => $air_booking_order_id, 'air_passenger_id' => $this->getLastInsertId()];
				foreach($passenger->seats as $seat)
				{
					$data['air_segment_id'] = $saved_air_segments[$seat['air_segment_ref_key']];
					$data['seat_code'] 		= $seat['seat_code'];

					$stmt2->execute($data);
				}
			}
		}
		catch(PDOException $e)
		{
			throw new AirException($e->getMessage() . $e->getLine());			
		}

		$query = "SELECT * FROM `air_booking_order` WHERE `id` = :id LIMIT 1;";
		$conds 	= ['id' => $air_booking_order_id];

		$stmt 	= DB::prepare($query);
		$stmt->execute($conds);

		self::$record = $stmt->fetch();

		$query 	= "SELECT * FROM `air_segment` WHERE `air_booking_order_id` = :air_booking_order_id;";
		$conds	= ['air_booking_order_id' => self::$record['id']];

		$stmt 	= DB::prepare($query);
		$stmt->execute($conds);

		self::$airSegments = $stmt->fetchAll();

		if(isset($_POST['api_key']) && !empty($_POST['api_key']) && $_POST['api_key'] == 'df0f040105f9a066c9e5b075f72d7eca')
		{
			//Samba Bank don't want notification on reservation
		}
		else
		{
			self::sendNotification();
		}

		return $air_booking_order_id;
	}

	public function getBooking($id)
	{
		try
		{
			$query = "SELECT * FROM `air_booking_order` WHERE id = :booking_id LIMIT 1";

			$stmt = $this->prepare($query);
			$stmt->execute(['booking_id' => $id]);

			return $stmt->fetch();
		}
		catch(PDOException $e)
		{
			throw new AirException("Database Error: " . $e->getMessage());
		}
	}

	public function getHistory($user_id)
	{
		try
		{
			$query = "SELECT * FROM `air_booking_order` WHERE user_id = :user_id ORDER By created_at DESC";

			$stmt = $this->prepare($query);
			$stmt->execute(['user_id' => $user_id]);

			return $stmt->fetchAll();
		}
		catch(PDOException $e)
		{
			throw new AirException("Database Error: " . $e->getMessage());
		}
	}

	private static function sendNotification()
	{
		$message = "Dear " . self::$record['name'] . ",\nYour " . (self::$record['trip_type'] == 'one_way' ? 'one way' : (self::$record['trip_type'] == 'multi_city' ? 'multi-city' : 'return')) . " ticket from " . self::$record['flight_from'] . " to " . self::$record['flight_to'] . " has been reserved.\nPNR: " . self::$record['reservation_locator_code'] . "\nReservation will be cancelled after 4 hours of non-payment.\nView Booking: https://bookme.pk/flights/booking/" . self::$record['reservation_locator_code'];
		Notification::sendSMS(self::$record['phone_number'], $message);

		// ob_start();
		// 	require_once "Airport.php";
		// 	require dirname(__FILE__) . "/../xml_requests/reservation_email.php";
		// $email_body = ob_get_clean();

		// Notification::sendEmail(self::$record['email'], self::$record['name'], "Air Ticket Reservation", $email_body);
	}
}