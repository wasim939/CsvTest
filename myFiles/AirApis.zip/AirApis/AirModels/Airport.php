<?php

/**
 * @Author: Umar Hayat
 * @Date:   2019-08-21 15:09:34
 * @Last Modified by:   Muhammad Umar Hayat
 * @Last Modified time: 2019-12-12 00:52:14
 */
require_once "AirException.php";
require_once "DB.php";

class Airport extends DB
{
	public static function get($country_code = 0)
	{
		try
		{
			$conds 	= [];
			if(!empty($country_code))
			{
				$query = "SELECT * FROM `airports` WHERE `countryCode` = :countryCode ORDER BY code ASC";
				$conds['countryCode'] = $country_code;
			}
			else
			{
				$query = "SELECT * FROM `airports` WHERE `countryCode` IS NOT NULL ORDER BY code ASC";
			}
			$stmt = self::prepare($query);
			$stmt->execute($conds);

			return $stmt->fetchAll();
		}
		catch(PDOException $e)
		{
			throw new AirException("Database Error: " . $e->getMessage());
		}
	}

	public static function search($search_query)
	{
		try 
		{
			$conds 	= [];
			if(empty($search_query))
			{
				throw new AirException("Query String Cannot Be Empty. ");
			}

			$query = "SELECT * FROM `airports` WHERE `code` LIKE :search_query OR `cityName` LIKE :search_query2 GROUP BY `code` ORDER BY `code` ASC";
			$conds['search_query'] 	= $search_query . "%";
			$conds['search_query2'] = $search_query . "%";
			$stmt 					= self::prepare($query);
			$stmt->execute($conds);

			return $stmt->fetchAll();
		} 
		catch (PDOException $e) 
		{
			throw new AirException("Database Error: " . $e->getMessage());
		}
	}

	public static function getFullnameByCode($code)
	{
		$query 	= "SELECT * FROM `airports` WHERE `code` = :code LIMIT 1;";
		$conds	= ['code' => $code];

		$stmt 	= self::prepare($query);
		$stmt->execute($conds);

		if($stmt->rowCount() > 0)
		{
			$temp = $stmt->fetch();

			return $temp['cityName'] . ", " . $temp['countryName'];
		}

		return $code;
	}

	public static function getAirportNameByCode($code)
	{
		$query 	= "SELECT * FROM `airports` WHERE `code` = :code LIMIT 1;";
		$conds	= ['code' => $code];

		$stmt 	= self::prepare($query);
		$stmt->execute($conds);

		if($stmt->rowCount() > 0)
		{
			$temp = $stmt->fetch();

			return $temp['name'];
		}

		return $code;
	}
}
