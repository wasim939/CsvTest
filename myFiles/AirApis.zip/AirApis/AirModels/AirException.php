<?php

/**
 * @Author: Umar Hayat
 * @Date:   2019-08-02 13:10:21
 * @Last Modified by:   Umar Hayat
 * @Last Modified time: 2019-08-02 14:09:14
 */
class AirException extends \Exception
{
	public function errorMessage() 
	{
		return $this->getMessage();
  	}
}