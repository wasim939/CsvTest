<?php

/**
 * @Author: Umar Hayat
 * @Date:   2019-08-06 18:34:39
 * @Last Modified by:   Umar Hayat
 * @Last Modified time: 2019-09-25 16:59:52
 */
require_once "AirModel.php";

class SeatMap extends AirModel
{
	private static function getSeatsByTraveler($air_segment_key, $travler_key, $node)
	{
		$seats 	= array('row' => []);
		$count 	= 0;
		foreach($node->children('air', true) as $rows)
		{
			if((string) $rows->getName() == 'Rows')
			{
				foreach($rows->attributes() as $key => $val)
				{
					if((string) $key == 'SegmentRef' && (string) $val == $air_segment_key)
					{
						foreach($rows->children('air', true) as $row)
						{
							if((string) $row->getName() == 'Row')
							{
								foreach($row->attributes() as $rKey => $rVal)
								{
									if((string) $rKey == 'Number')
									{
										$tempNumber = (string) $rVal;
									}
									elseif((string) $rKey == 'SearchTravelerRef' && (string) $rVal == $travler_key)
									{
										$seats['row'][$count]	= array('number' => $tempNumber, 'seats' => []);
										$icount = 0;
										foreach($row->children('air', true) as $seat)
										{
											if((string) $seat->getName() == 'Facility')
											{
												$seats['row'][$count]['seats'][$icount]['paid'] = false;
												foreach($seat->attributes() as $sKey => $sVal)
												{
													if((string) $sKey == 'Type')
													{
														$seats['row'][$count]['seats'][$icount]['type']	= (string) $sVal; 
													}
													elseif((string) $sKey == 'SeatCode')
													{
														$seats['row'][$count]['seats'][$icount]['seat_code']	= (string) $sVal; 
													}
													elseif((string) $sKey == 'Availability')
													{
														$seats['row'][$count]['seats'][$icount]['availability']	= (string) $sVal; 
													}
													elseif((string) $sKey == 'Paid')
													{
														$seats['row'][$count]['seats'][$icount]['paid']	= (string) $sVal == "true" ? true : false; 
													}
													elseif((string) $sKey == 'OptionalServiceRef' && $seats['row'][$count]['seats'][$icount]['paid'])
													{
														$seats['row'][$count]['seats'][$icount]['optional_service_ref_key'] = (string) $sVal;
														$seats['row'][$count]['seats'][$icount]['price'] = self::getPaidSeatPrice($sVal, $node);
													}
												}
												if((string) $seats['row'][$count]['seats'][$icount]['type'] == 'Seat')
												{
													$seats['row'][$count]['seats'][$icount]['characteristices'] = array();
													foreach($seat->children('air', true) as $characteristic)
													{
														if((string) $characteristic->getName() == 'Characteristic')
														{
															foreach($characteristic->attributes() as $cKey => $cVal)
															{
																if((string) $cKey == 'Value')
																{
																	$seats['row'][$count]['seats'][$icount]['characteristices'][] = (string) $cVal;
																}
															}
														}
													}
												}
												$icount++;
											}
										}
										$count++;
									}
								}
							}
						}
					}
				}
			}
		}

		return $seats;
	}

	private static function getTravelers($node)
	{
		$travlers 	= array();
		$count 		= 0;
		foreach($node->children('air', true) as $searchTraveler)
		{
			if((string) $searchTraveler->getName() == 'SearchTraveler')
			{
				foreach($searchTraveler->attributes() as $key => $val)
				{
					if((string) $key == 'Key')
					{
						$travlers[$count]['key']	= (string) $val;
					}
					elseif((string) $key == 'Code')
					{
						$travlers[$count]['code']	= (string) $val;
					}
				}
				$count++;
			}
		}

		return $travlers;
	}

	private static function getPaidSeatPrice($optional_service_ref_key, $node)
	{
		$price = "PKR0";
		foreach($node->children('air', true) as $optionalServices)
		{
			if((string) $optionalServices->getName() == 'OptionalServices')
			{
				foreach($optionalServices->children('air', true) as $optionalService)
				{
					if((string) $optionalService->getName() == 'OptionalService')
					{
						foreach($optionalService->attributes() as $key => $val)
						{
							if($key == 'Key' && (string) $val == $optional_service_ref_key)
							{
								foreach($optionalService->attributes() as $key => $val)
								{
									if($key == 'TotalPrice')
									{
										$price = (string) $val;

										return $price;
									}
								}
							}
						}
					}
				}
			}
		}

		return $price;
	}

	public static function parseResponse()
	{
		if(!empty(self::$responseArray))
			return self::$responseArray;

		if(empty(self::$rawResponse))
		{
			throw new AirException("Response from server is empty.");
		}

		$xml 	= simplexml_load_String(self::$rawResponse, null, null, 'SOAP', true);	
		
		if(empty($xml))
		{
			throw new AirException("Encoding Error.");
			return false;
		}

		$Results = $xml->children('SOAP', true);
		foreach($Results->children('SOAP', true) as $fault)
		{
			if((string) $fault->getName() == 'Fault')
			{
				throw new AirException("Error occurred request/response processing: " . $fault->__toString());
				return false;
			}
		}
		$Results = $Results->children('air', true)[0];

		$travlers 	= self::getTravelers($Results);
		if(empty($travlers))
		{
			throw new Exception("No travler found.");
			return false;
		}

		$count 		= 0;
		$scount 	= 0;
		self::$responseArray['travler'] = array();

		foreach($Results->children('air', true) as $airSegment)
		{
			if((string) $airSegment->getName() == 'AirSegment')
			{
				self::$responseArray['air_segment'][$scount]['seat_map_available'] = false;
				foreach($airSegment->attributes() as $key => $val)
				{
					if((string) $key == 'Key')
					{
						self::$responseArray['air_segment'][$scount]['air_segment_ref_key']	= (string) $val;

						foreach($travlers as $travler)
						{
							self::$responseArray['travler'][$count]	= array('air_segment_key' => (string) $val,'search_traveler_key' => $travler['key'], 'travler_code' => $travler['code'], 'seats' => []);
							self::$responseArray['travler'][$count]['seats'] = self::getSeatsByTraveler($val, $travler['key'], $Results);

							if(isset(self::$responseArray['travler'][$count]['seats']['row']) && count(self::$responseArray['travler'][$count]['seats']['row']) > 0)
							{
								self::$responseArray['air_segment'][$scount]['seat_map_available'] = true;
							}

							$count++;
						}
					}
					elseif((string) $key == "Group")
					{
						self::$responseArray['air_segment'][$scount]['group']	= (string) $val;
					}
					elseif((string) $key == "Carrier")
					{											
						$tempAirline 	= (string) $val;
						self::$responseArray['air_segment'][$scount]['carrier']	= $tempAirline;
						self::$responseArray['air_segment'][$scount]['airline']	= self::airlineByCode($tempAirline);
					}
					elseif((string) $key == "FlightNumber")
					{
						$val = (string) $val;
						self::$responseArray['air_segment'][$scount]['flight']	= $tempAirline . $val;
						self::$responseArray['air_segment'][$scount]['flight_number']	= $val;
					}
					elseif((string) $key == "ProviderCode")
					{									
						self::$responseArray['air_segment'][$scount]['provider_code']	= (string) $val;			
					}
					elseif((string) $key == "Origin")
					{											
						self::$responseArray['air_segment'][$scount]['from']	= (string) $val;	
					}
					elseif((string) $key == "Destination")
					{											
						self::$responseArray['air_segment'][$scount]['to']	= (string) $val;	
					}
					elseif((string) $key == "DepartureTime")
					{											
						self::$responseArray['air_segment'][$scount]['depart']	= (string) $val;	
					}
					elseif((string) $key == "ArrivalTime")
					{											
						self::$responseArray['air_segment'][$scount]['arrival']	= (string) $val;	
					}
					elseif((string) $key == "FlightTime")
					{											
						self::$responseArray['air_segment'][$scount]['flight_time']	= (string) $val;	
					}
					elseif((string) $key == "TravelTime")
					{											
						self::$responseArray['air_segment'][$scount]['travel_time']	= (string) $val;	
					}
					elseif((string) $key == "Distance")
					{											
						self::$responseArray['air_segment'][$scount]['distance']	= (string) $val;	
					}
					elseif((string) $key == "ClassOfService")
					{											
						self::$responseArray['air_segment'][$scount]['class']	= (string) $val;	
					}
					elseif((string) $key == "Equipment")
					{											
						self::$responseArray['air_segment'][$scount]['plane']	 = (string) $val;	
						self::$responseArray['air_segment'][$scount]['equipment'] =  self::planeByCode($val);	
					}
					elseif((string) $key == "ChangeOfPlane")
					{											
						self::$responseArray['air_segment'][$scount]['change_of_plane']	= ((string) $val == "true" ? true : false);	
					}
					elseif((string) $key == "OptionalServicesIndicator")
					{											
						self::$responseArray['air_segment'][$scount]['optional_services_indicator']	= ((string) $val == "true" ? true : false);	
					}
					elseif((string) $key == "AvailabilityDisplayType")
					{											
						self::$responseArray['air_segment'][$scount]['availability_display_type']	= (string) $val;	
					}
				}
				$scount++;
			}
		}

		file_put_contents(getcwd() . '/cache/air/' . self::$cacheFile . '_parsed.dat', json_encode(self::$responseArray));
		// print_r(self::$responseArray);die;
		return self::$responseArray;
	}
}