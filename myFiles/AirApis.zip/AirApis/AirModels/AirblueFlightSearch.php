<?php

/**
 * @Author: mailm
 * @Date:   2020-01-22 19:09:00
 * @Last Modified by:   mailm
 * @Last Modified time: 2020-01-31 17:13:36
 */
require_once "AirModel.php";
require_once "AirException.php";
require_once "simple_html_dom.php";

class AirblueFlightSearch extends AirModel
{
	private static $EndPoint = "https://www.airblue.com/bookings/flight_selection.aspx?TT=_TRIP_TYPE_&DC=_ORIGIN_&AC=_DESTINATION_&AM=_DEPART_YEAR_-_DEPART_MONTH_&AD=_DEPART_DAY_&RM=_RETURN_YEAR_-_RETURN_MONTH_&RD=_RETURN_DAY_&FL=&CC=Y&CD=&PA=_ADT_&PC=_CHD_&PI=_INF_&x=0&y=0";

	private static $TripType = "one_way";

	private static $From 	= "";
	private static $To 		= "";
	private static $FromIATA 	= "";
	private static $ToIATA 		= "";

	public static function makeRequest($request)
	{
		$dep_dates = explode('-', $request['dep_date']);
		$arr_dates = explode('-', $request['return_date'] ?? '');

		self::$EndPoint = str_replace(['_TRIP_TYPE_', '_ORIGIN_', '_DESTINATION_', '_ADT_', '_CHD_', '_INF_', '_DEPART_DAY_', '_DEPART_MONTH_', '_DEPART_YEAR_', '_RETURN_DAY_', '_RETURN_MONTH_', '_RETURN_YEAR_'], [(isset($request['return_date']) && !empty($request['return_date'])) ? 'RT' : 'OW', $request['from'], $request['to'], $request['no_of_adults'] ?? '1', $request['no_of_children'] ?? '0', $request['no_of_infants'] ?? '0', $dep_dates[0], $dep_dates[1], $dep_dates[2], $arr_dates[0] ?? '', $arr_dates[1] ?? '', $arr_dates[2] ?? ''], self::$EndPoint);
        
		self::$TripType = (isset($request['return_date']) && !empty($request['return_date'])) ? 'return' : 'one_way';

		self::$From 	= $request['from'];
		self::$To 		= $request['to'];
		self::$FromIATA = self::cityToIATA($request['from']);
		self::$ToIATA 	= self::cityToIATA($request['to']);

		$ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, self::$EndPoint);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $res = curl_exec($ch);
        
		$html 	= str_get_html($res);
		$count 	= 0;

		$outbounds 	= [];
		$inbounds 	= [];
        
        if(empty($html))
            return [];

		foreach($html->find('table.flight_selection tbody') as $i => $table)
		{
			foreach($table->find('tbody') as $k => $tbody)
			{
				self::$responseArray[$count] = array();

				foreach($tbody->find('tr') as $tr)
				{
					$sub_count 	= 0;
					$td_nodes 	= $tr->find('tr');

					if(!isset($td_nodes[0]))
						continue;

					$date 		= $dep_dates[0] . '-' . $dep_dates[1] . '-' . $dep_dates[2];
					$stops 		= (int) $td_nodes[2]->find('span')[0]->innertext;
					// $stops_node = $stops > 0 ? $td_nodes[5]->find('div table td table tr') : null;

					self::$responseArray[$count]['journey_ref_id'] 	= md5(time() . uniqid() . rand(99, 99999)) . 'ED';

					if($stops == 0)
					{
						self::$responseArray[$count]['connection'] 		= array();
						self::$responseArray[$count]['outbound_route']	= array('is_connecting_flight' => false);

						self::setArrayValues($date, $count, 'outbound_route', $sub_count, $td_nodes);
					}
					else
					{
						self::$responseArray[$count]['connection'] 		= array();
						self::$responseArray[$count]['outbound_route']	= array('is_connecting_flight' => true);

						self::setArrayValues($date, $count, 'outbound_route', $sub_count, $td_nodes);

						// foreach($stops_node as $j => $stop_tr)
						// {
						// 	if($j == 0)
						// 		continue;
						// 	if($j == 1)
						// 	{
						// 		$td_sub_nodes 	= $stop_tr->find('td');

						// 		self::setArrayValues($date, $count, 'outbound_route', $sub_count, $td_sub_nodes, true);
						// 	}
						// 	else
						// 	{
						// 		self::setArrayValues($date, $count, 'outbound_route', $sub_count, $td_nodes);

						// 		$td_sub_nodes 	= $stop_tr->find('td');

						// 		self::setArrayValues($date, $count, 'outbound_route', $sub_count, $td_sub_nodes, true);
						// 	}

						// 	$sub_count++;
						// }
					}
					self::setPriceValues($count, str_replace([' ', ','], '', $tr->find('td.Availability_whitebold_border-left', 0)->find('span', 0)->plaintext), $request['no_of_adults'] ?? 1, $request['no_of_children'] ?? 0, $request['no_of_infants'] ?? 0);

					$count++;
				}

				if(isset($request['return_date']) && !empty($request['return_date'])) //Round Trip
				{
					if(empty(self::$responseArray) || empty(self::$responseArray[0]))
					{
						self::$responseArray 	= [];
						continue;
					}

					if($i == 0)
					{
						$outbounds 				= self::$responseArray;
						self::$responseArray 	= [];
						$count 					= 0;
					}
					else
					{
						$inbounds 				= self::$responseArray;
						self::$responseArray 	= [];
						$count 					= 0;
						break;
					}
				}
				else //One Way
				{
					break;
				}
			}
		}

		if(!empty($outbounds) && !empty($inbounds))
		{
			foreach($outbounds as $i => $outbound)
			{
				$outbound_price = (int) str_replace('PKR', '', $outbound['approx_total_price']);

				foreach($inbounds as $inbound)
				{
					self::$responseArray[$count] 					= $outbound;
					self::$responseArray[$count]['inbound_route'] 	= $inbound['outbound_route'];

					$inbound_price = (int) str_replace('PKR', '', $inbound['approx_total_price']);

					self::$responseArray[$count]['approx_total_price'] = 'PKR' . ($outbound_price + $inbound_price);

					$count++;
				}
			}
		}

		return self::$responseArray;
	}

	private static function setArrayValues($date, $count, $type, $sub_count, $td_nodes, $is_sub_node = false)
	{
		// if($a)
		// {
		// 	echo $td_nodes[0]->plaintext . "\n";
		// 	echo $td_nodes[1]->plaintext . "\n";
		// 	echo $td_nodes[2]->plaintext . "\n";
		// 	echo $td_nodes[3]->plaintext . "\n";
		// 	echo $td_nodes[4]->plaintext . "\n";
		// 	echo (int) ($td_nodes[5]->find('a')[0] ?? $td_nodes[5]->find('span')[0])->plaintext . "\n";
		// 	echo $td_nodes[6]->plaintext . "\n";
		// 	echo $td_nodes[7]->plaintext . "\n";

		// 	die;
		// }
		if($is_sub_node)
		{
			self::$responseArray[$count]['outbound_route'][$sub_count]['from'] = self::cityToIATA($td_nodes[0]->innertext);
			self::$responseArray[$count]['outbound_route'][$sub_count]['to'] = self::cityToIATA($td_nodes[1]->innertext);
			self::$responseArray[$count]['outbound_route'][$sub_count]['depart'] = $date . 'T' . $td_nodes[2]->innertext . ':00.000+05:00';
			self::$responseArray[$count]['outbound_route'][$sub_count]['arrival'] =  $date . 'T' . $td_nodes[3]->innertext . ':00.000+05:00';
		}
		else
		{
			self::$responseArray[$count][$type][$sub_count]['class'] = 'N/A';
			self::$responseArray[$count][$type][$sub_count]['cabin_class'] = 'Economy';
			self::$responseArray[$count][$type][$sub_count]['fare_info_ref_key'] = 'N/A';
			self::$responseArray[$count][$type][$sub_count]['fare_basis'] = 'N/A';
			self::$responseArray[$count][$type][$sub_count]['baggage_allowance'] = ['weight' => 'N/A', 'unit' => 'Kilograms', 'pieces' => 0];
			self::$responseArray[$count][$type][$sub_count]['air_segment_ref_key'] = 'N/A';
			self::$responseArray[$count][$type][$sub_count]['flight_detail_ref_key'] = 'N/A';
			self::$responseArray[$count][$type][$sub_count]['flight_time'] = self::readableToMinutes($td_nodes[6]->plaintext);
			self::$responseArray[$count][$type][$sub_count]['flight_time_readable'] = '00:' . $td_nodes[6]->plaintext;
			self::$responseArray[$count][$type][$sub_count]['travel_time'] = self::readableToMinutes($td_nodes[6]->plaintext);
			self::$responseArray[$count][$type][$sub_count]['travel_time_readable'] = '00:' . $td_nodes[6]->plaintext;
			self::$responseArray[$count][$type][$sub_count]['plane'] = 'N/A';
			self::$responseArray[$count][$type][$sub_count]['equipment'] = 'N/A';
			self::$responseArray[$count][$type][$sub_count]['group'] = 'N/A';
			self::$responseArray[$count][$type][$sub_count]['carrier'] = 'ED';
			self::$responseArray[$count][$type][$sub_count]['airline'] = 'Airblue';
			self::$responseArray[$count][$type][$sub_count]['airline_logo'] = 'https://bookme.pk/images/airlines/ED.svg';
			self::$responseArray[$count][$type][$sub_count]['flight'] = $td_nodes[2]->find('span', 1)->plaintext;
			self::$responseArray[$count][$type][$sub_count]['flight_number'] = 'N/A';
			self::$responseArray[$count][$type][$sub_count]['from'] = self::$FromIATA;
			self::$responseArray[$count][$type][$sub_count]['to'] 	= self::$ToIATA;
			self::$responseArray[$count][$type][$sub_count]['depart'] = $date . 'T' . self::convert12To24Hours($td_nodes[1]->plaintext) . ':00.000+05:00';
			self::$responseArray[$count][$type][$sub_count]['arrival'] =  $date . 'T' . self::convert12To24Hours($td_nodes[3]->plaintext) . ':00.000+05:00';
			self::$responseArray[$count][$type][$sub_count]['distance'] = 'N/A';
			self::$responseArray[$count][$type][$sub_count]['e_ticket_ability'] = 'N/A';
			self::$responseArray[$count][$type][$sub_count]['change_of_plane'] = 'N/A';
			self::$responseArray[$count][$type][$sub_count]['link_availability'] = 'N/A';
			self::$responseArray[$count][$type][$sub_count]['polled_availablility_option'] = 'N/A';
			self::$responseArray[$count][$type][$sub_count]['optional_services_indicator'] = 'N/A';
			self::$responseArray[$count][$type][$sub_count]['availability_source'] = 'N/A';
			self::$responseArray[$count][$type][$sub_count]['availability_display_type'] = 'N/A';
		}
	}

	private static function setPriceValues($count, $amount, $adt, $chd, $inf)
	{
		$one_adult 	= (int) str_replace('PKR', '', $amount);
		$one_chd 	= floor(($one_adult / 100) * 80);
		$one_inf 	= floor(($one_adult / 100) * 20);

		$amount 	= $one_adult * $adt;
		$amount 	+= $one_chd * $chd;
		$amount 	+= $one_inf * $inf;


		self::$responseArray[$count]['is_refundable'] 	= true;
		self::$responseArray[$count]['change_penalty'] 	= 'N/A';
		self::$responseArray[$count]['cancel_penalty'] 	= 'N/A';
		self::$responseArray[$count]['air_pricing_solution_ref_key'] = 'N/A';
		self::$responseArray[$count]['approx_total_price'] 	= 'PKR' . $amount;
		self::$responseArray[$count]['base_price'] 			= 'N/A';
		self::$responseArray[$count]['approx_base_price'] 	= 'N/A';
		self::$responseArray[$count]['taxes'] 				= 'N/A';
		self::$responseArray[$count]['approx_taxes'] 		= 'N/A';
		self::$responseArray[$count]['direction'] 			= self::$TripType;
	}

	private static function cityToIATA($name)
	{
		$name = strtolower($name);

		if(strpos($name, 'faisalabad') !== false)
			return 'LYP';
		if(strpos($name, 'islamabad') !== false)
			return 'ISB';
		if(strpos($name, 'karachi') !== false)
			return 'KHI';
		if(strpos($name, 'lahore') !== false)
			return 'LHE';
		if(strpos($name, 'peshawar') !== false)
			return 'PEW';
		if(strpos($name, 'quetta') !== false)
			return 'UET';
	}

	private static function convert12To24Hours($time)
	{
		return date("H:i", strtotime($time));
	}

	private static function readableToMinutes($input)
	{
		$temp = explode(':', $input);

		return ((int) $temp[0]) * 60 + ((int) $temp[1]);
	}
}