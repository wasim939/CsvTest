<?php

/**
 * @Author: Umar Hayat
 * @Date:   2019-08-16 15:26:40
 * @Last Modified by:   mailm
 * @Last Modified time: 2020-01-28 02:10:40
 */
require_once "AirModel.php";
require_once "AirException.php";
require_once "AirBookingOrder.php";

class Reservation extends AirModel
{
	public static $Passengers 	= [];
	public static $PostalInfo 	= [];
	private static $AirBookingOrder;

	public static function parseResponse($isReturn = false)
	{
		if(!empty(self::$responseArray))
			return self::$responseArray;

		if(empty(self::$rawResponse))
		{
			throw new AirException("Response from server is empty.");
		}

		$xml 	= simplexml_load_String(self::$rawResponse, null, null, 'SOAP', true);	
		
		if(empty($xml))
		{
			throw new AirException("Encoding Error.");
			return false;
		}

		$Results = $xml->children('SOAP', true);
		foreach($Results->children('SOAP', true) as $fault)
		{
			if(strcmp($fault->getName(), 'Fault') == 0)
			{
				foreach ($fault->children() as $child)
				{
					if(strcmp($child->getName(), 'faultstring') == 0)
					{
						throw new AirException("Error occurred response processing: " . $child);
						return false;
					}
				}
			}
		}

		$Results = $Results->children('universal', true)[0];

		$count 										= 0;
		self::$responseArray['response_messages'] 	= array();

		foreach($Results->children('common_v42_0', true) as $responseMessage)
		{
			if(strcmp($responseMessage->getName(), "ResponseMessage") == 0)
			{
				foreach($responseMessage->attributes() as $key => $val)
				{
					if(strcmp($key, "Code") == 0)
					{
						self::$responseArray['response_messages'][$count]['code']	= (string) $val;
					}
					elseif(strcmp($key, "Type") == 0)
					{
						self::$responseArray['response_messages'][$count]['type']	= (string) $val;
					}
				}
				self::$responseArray['response_messages'][$count]['message'] = (string) $responseMessage;
				$count++;
			}
		}

		$count = 0;

		foreach($Results->children('universal', true) as $universalRecord)
		{
			if(strcmp($universalRecord->getName(), "UniversalRecord") == 0)
			{
				foreach($universalRecord->attributes() as $key => $val)
				{
					if(strcmp($key, "LocatorCode") == 0)
					{
						self::$responseArray['universal_locator_code'] = (string) $val;
					}
					elseif(strcmp($key, "Status") == 0)
					{
						self::$responseArray['status'] = (string) $val;
					}
				}

				foreach($universalRecord->children('common_v30_0', true) as $actionStatus)
				{
					if(strcmp($actionStatus->getName(), "ActionStatus") == 0)
					{
						foreach($actionStatus->attributes() as $key => $val)
						{
							if(strcmp($key, "TicketDate") == 0)
							{
								self::$responseArray['ticket_date'] = (string) $val;
							}
							elseif(strcmp($key, "ProviderReservationInfoRef") == 0)
							{
								self::$responseArray['provider_reservation_info_ref_key'] = (string) $val;
							}
						}
					}
				}

				foreach($universalRecord->children('universal', true) as $actionStatus)
				{
					if(strcmp($actionStatus->getName(), "ProviderReservationInfo") == 0)
					{
						foreach($actionStatus->attributes() as $key => $val)
						{
							if(strcmp($key, "LocatorCode") == 0)
							{
								self::$responseArray['reservation_locator_code'] = (string) $val;
							}
							elseif(strcmp($key, "OwningPCC") == 0)
							{
								self::$responseArray['owning_pcc'] = (string) $val;
							}
							elseif(strcmp($key, "Key") == 0)
							{
								self::$responseArray['provider_reservation_info_key'] = (string) $val;
							}
						}
					}
				}

				foreach($universalRecord->children('air', true) as $airReservation)
				{
					if(strcmp($airReservation->getName(), "AirReservation") == 0)
					{
						foreach($airReservation->attributes() as $key => $val)
						{
							if(strcmp($key, "LocatorCode") == 0)
							{
								self::$responseArray['air_reservation_locator_code'] = (string) $val;
							}
						}

						$baggage_count = 0;
						foreach($airReservation->children('air', true) as $airSegment)
						{
							if((string) $airSegment->getName() == "AirSegment")
							{
								foreach($airSegment->attributes() as $key => $val)
								{
									if(strcmp($key, "Key") == 0)
									{
										self::$responseArray['air_segment'][$count]['air_segment_ref_key']	= (string) $val;
									}
									elseif(strcmp($key, "Group") == 0)
									{
										self::$responseArray['air_segment'][$count]['group']	= (string) $val;
									}
									elseif(strcmp($key, "Carrier") == 0)
									{											
										$tempAirline 	= (string) $val;
										self::$responseArray['air_segment'][$count]['carrier']	= $tempAirline;
										self::$responseArray['air_segment'][$count]['airline']	= self::airlineByCode($tempAirline);
									}
									elseif(strcmp($key, "FlightNumber") == 0)
									{
										$val = (string) $val;
										self::$responseArray['air_segment'][$count]['flight']	= $tempAirline . $val;
										self::$responseArray['air_segment'][$count]['flight_number']	= $val;
									}
									elseif(strcmp($key, "ProviderCode") == 0)
									{									
										self::$responseArray['air_segment'][$count]['provider_code']	= (string) $val;			
									}
									elseif(strcmp($key, "Origin") == 0)
									{											
										self::$responseArray['air_segment'][$count]['from']	= (string) $val;	
									}
									elseif(strcmp($key, "Destination") == 0)
									{											
										self::$responseArray['air_segment'][$count]['to']	= (string) $val;	
									}
									elseif(strcmp($key, "DepartureTime") == 0)
									{											
										self::$responseArray['air_segment'][$count]['depart']	= (string) $val;	
									}
									elseif(strcmp($key, "ArrivalTime") == 0)
									{											
										self::$responseArray['air_segment'][$count]['arrival']	= (string) $val;	
									}
									elseif(strcmp($key, "FlightTime") == 0)
									{											
										self::$responseArray['air_segment'][$count]['flight_time']	= (string) $val;	
									}
									elseif(strcmp($key, "TravelTime") == 0)
									{											
										self::$responseArray['air_segment'][$count]['travel_time']	= (string) $val;	
									}
									elseif(strcmp($key, "Distance") == 0)
									{											
										self::$responseArray['air_segment'][$count]['distance']	= (string) $val;	
									}
									elseif(strcmp($key, "ClassOfService") == 0)
									{											
										self::$responseArray['air_segment'][$count]['class']	= (string) $val;	
									}
									elseif(strcmp($key, "Equipment") == 0)
									{											
										self::$responseArray['air_segment'][$count]['plane']	 = (string) $val;	
										self::$responseArray['air_segment'][$count]['equipment'] =  self::planeByCode($val);	
									}
									elseif(strcmp($key, "ChangeOfPlane") == 0)
									{											
										self::$responseArray['air_segment'][$count]['change_of_plane']	= ((string) $val == "true" ? true : false);	
									}
									elseif(strcmp($key, "OptionalServicesIndicator") == 0)
									{											
										self::$responseArray['air_segment'][$count]['optional_services_indicator']	= ((string) $val == "true" ? true : false);	
									}
									elseif(strcmp($key, "AvailabilitySource") == 0)
									{											
										self::$responseArray['air_segment'][$count]['availability_source']	= (string) $val;	
									}
									elseif(strcmp($key, "AvailabilityDisplayType") == 0)
									{											
										self::$responseArray['air_segment'][$count]['availability_display_type']	= (string) $val;	
									}
								}

								$m_count = 0;
								foreach($airSegment->children('common_v30_0', true) as $sellMessage)
								{
									if(strcmp($sellMessage->getName(), "SellMessage") == 0)
									{
										self::$responseArray['air_segment'][$count]['messages'][$m_count++] = (string) $sellMessage;  
									}
								}
								$count++;
							}
							// elseif((string) $airSegment->getName() == "AirPricingInfo")
							// {
							// 	foreach($airSegment->children('air', true) as $airPricingInfo)
							// 	{
							// 		if((string) $airPricingInfo->getName() == "FareInfo")
							// 		{
							// 			foreach($airPricingInfo->children('air', true) as $fareInfo)
							// 			{
							// 				if((string) $fareInfo->getName() == "FareInfo")
							// 				{
							// 					self::$responseArray['air_segment'][$baggage_count]['baggage_texts'] =  ;
							// 				}
							// 			}
							// 		}
							// 	}
							// }
						}
					}
				}
			}
		}

		file_put_contents(getcwd() . '/cache/air/' . self::$cacheFile . '_parsed.dat', json_encode(self::$responseArray));

		return self::$responseArray;
	}

	public static function save($user_id, $ref_id, $journey_ref_id)
	{
		if(empty($ref_id))
		{
			throw new AirException("Reference ID Required.");
		}
		elseif(!file_exists(getcwd() . '/cache/air/reference_data/' . $ref_id . '_raw_price.dat') || !file_exists(getcwd() . '/cache/air/reference_data/' . $ref_id . '_parsed_price.dat'))
		{
			throw new AirException("'Invalid Reference ID.");
		}

		if(empty($journey_ref_id))
		{
			throw new AirException("Invalid Journey Reference ID.");
		}

		if(empty(self::$Passengers))
		{
			throw new AirException("Passengers Cannot Be Empty.");
		}

		if(empty(self::$PostalInfo))
		{
			throw new AirException("Passenger's Info Required.");
		}

		$air_price = json_decode(file_get_contents(getcwd() . '/cache/air/reference_data/' . $ref_id . '_parsed_price.dat'), true);
		if(json_last_error() != JSON_ERROR_NONE || empty($air_price))
		{
			throw new AirException("Something Went Wrong. Please Search Again.");
		}

		self::$AirBookingOrder 	= new AirBookingOrder;

		//Basic
		self::$AirBookingOrder->user_id 		= $user_id;
		self::$AirBookingOrder->ref_id  		= $ref_id;
		self::$AirBookingOrder->journey_ref_id  = $journey_ref_id;
		self::$AirBookingOrder->trip_type  		= $air_price['direction'];
		self::$AirBookingOrder->carrier  		= $air_price['carrier'];
		self::$AirBookingOrder->airline  		= $air_price['airline'];
		self::$AirBookingOrder->flight_from  	= $air_price['from'];
		self::$AirBookingOrder->flight_to  		= $air_price['to'];
		self::$AirBookingOrder->class  			= $air_price['class'];
		self::$AirBookingOrder->total_adults  	= $air_price['no_of_adults'];
		self::$AirBookingOrder->total_children  = $air_price['no_of_children'];
		self::$AirBookingOrder->total_infants  	= $air_price['no_of_infants'];

		//Fares
		$tmp 		= [];
		preg_match('/([A-Za-z]+)(\d+)/', $air_price['fare']['total_price'], $tmp);
		$currency 	= isset($tmp[1]) ? $tmp[1] : "PKR";

		self::$AirBookingOrder->approx_total_price  = str_replace($currency, '', $air_price['fare']['approx_total_price']);
		self::$AirBookingOrder->total_price   	= str_replace($currency, '', $air_price['fare']['total_price']);
		self::$AirBookingOrder->base_price   	= str_replace($currency, '', $air_price['fare']['base_price']);
		self::$AirBookingOrder->approx_base_price   = str_replace($currency, '', $air_price['fare']['approx_base_price']);
		self::$AirBookingOrder->taxes   		= str_replace($currency, '', $air_price['fare']['taxes']);
		self::$AirBookingOrder->approx_taxes   	= str_replace($currency, '', $air_price['fare']['approx_taxes']);
		self::$AirBookingOrder->fees    		= str_replace($currency, '', $air_price['fare']['fees']);
		self::$AirBookingOrder->currency     	= $currency;

		//Air Segments
		foreach($air_price['air_segment'] as $i => $air_segment)
		{
			self::$AirBookingOrder->AirSegments[$i]	= new AirSegment;
			self::$AirBookingOrder->AirSegments[$i]->air_segment_ref_key = $air_segment['air_segment_ref_key'];
			self::$AirBookingOrder->AirSegments[$i]->air_group 	= $air_segment['group'];
			self::$AirBookingOrder->AirSegments[$i]->carrier 	= $air_segment['carrier'];
			self::$AirBookingOrder->AirSegments[$i]->airline 	= $air_segment['airline'];
			self::$AirBookingOrder->AirSegments[$i]->flight 	= $air_segment['flight'];
			self::$AirBookingOrder->AirSegments[$i]->flight_number = $air_segment['flight_number'];
			self::$AirBookingOrder->AirSegments[$i]->provider_code = $air_segment['provider_code'];
			self::$AirBookingOrder->AirSegments[$i]->travel_from = $air_segment['from'];
			self::$AirBookingOrder->AirSegments[$i]->travel_to 	 = $air_segment['to'];
			self::$AirBookingOrder->AirSegments[$i]->departure_datetime = $air_segment['depart'];
			self::$AirBookingOrder->AirSegments[$i]->departure_timezone = (new Datetime($air_segment['depart']))->format('P');
			self::$AirBookingOrder->AirSegments[$i]->arrival_datetime 	= $air_segment['arrival'];
			self::$AirBookingOrder->AirSegments[$i]->arrival_timezone 	= (new Datetime($air_segment['arrival']))->format('P');
			self::$AirBookingOrder->AirSegments[$i]->flight_time = $air_segment['flight_time'];
			self::$AirBookingOrder->AirSegments[$i]->travel_time = $air_segment['travel_time'];
			self::$AirBookingOrder->AirSegments[$i]->distance = $air_segment['distance'];
			self::$AirBookingOrder->AirSegments[$i]->class 	  = $air_segment['class'];
			self::$AirBookingOrder->AirSegments[$i]->plane 	  = $air_segment['plane'];
			self::$AirBookingOrder->AirSegments[$i]->equipment= $air_segment['equipment'];
			self::$AirBookingOrder->AirSegments[$i]->change_of_plane = $air_segment['change_of_plane'];
			self::$AirBookingOrder->AirSegments[$i]->optional_services_indicator = $air_segment['optional_services_indicator'];
			self::$AirBookingOrder->AirSegments[$i]->availability_display_type 	 = $air_segment['availability_display_type'];
		}

		//Air Passenger
		foreach(self::$Passengers as $i => $passenger)
		{
			self::$AirBookingOrder->AirPassengers[$i]	= new AirPassenger;
			self::$AirBookingOrder->AirPassengers[$i]->traveler_type 	= $passenger['traveler_type'];
			self::$AirBookingOrder->AirPassengers[$i]->prefix 			= $passenger['prefix'];
			self::$AirBookingOrder->AirPassengers[$i]->firstname 		= $passenger['firstname'];
			self::$AirBookingOrder->AirPassengers[$i]->lastname 		= $passenger['lastname'];
			self::$AirBookingOrder->AirPassengers[$i]->gender 			= $passenger['gender'];
			self::$AirBookingOrder->AirPassengers[$i]->age 				= $passenger['age'];
			self::$AirBookingOrder->AirPassengers[$i]->dob 				= $passenger['dob'];
			self::$AirBookingOrder->AirPassengers[$i]->country 			= $passenger['country'];
			self::$AirBookingOrder->AirPassengers[$i]->nationality 		= $passenger['nationality'];
			self::$AirBookingOrder->AirPassengers[$i]->passport_no 		= $passenger['passport_no'];
			self::$AirBookingOrder->AirPassengers[$i]->passport_expiry 	= $passenger['passport_expiry'];
			self::$AirBookingOrder->AirPassengers[$i]->seats 			= $passenger['seats'];
		}

		//Departure times
		self::$AirBookingOrder->initial_departure_datetime	= self::$AirBookingOrder->AirSegments[0]->departure_datetime;
		self::$AirBookingOrder->initial_departure_timezone 	= self::$AirBookingOrder->AirSegments[0]->departure_timezone;
		self::$AirBookingOrder->last_departure_datetime 	= end(self::$AirBookingOrder->AirSegments)->departure_datetime;
		self::$AirBookingOrder->last_departure_timezone 	= end(self::$AirBookingOrder->AirSegments)->departure_timezone;
		//Reservation Location
		self::$AirBookingOrder->universal_locator_code 		= self::$responseArray['universal_locator_code'];
		self::$AirBookingOrder->reservation_status 			= self::$responseArray['status'];
		self::$AirBookingOrder->reservation_locator_code 	= self::$responseArray['reservation_locator_code'];
		self::$AirBookingOrder->owning_pcc 					= self::$responseArray['owning_pcc'];
		self::$AirBookingOrder->provider_reservation_info_key= self::$responseArray['provider_reservation_info_key'];
		self::$AirBookingOrder->air_reservation_locator_code= self::$responseArray['air_reservation_locator_code'];
		self::$AirBookingOrder->universal_locator_code 		= self::$responseArray['universal_locator_code'];
		self::$AirBookingOrder->air_pricing_info_key 		= json_encode($air_price['air_pricing_info_key']);
		//System's Statuses
		self::$AirBookingOrder->status 			= 1;
		self::$AirBookingOrder->service_status 	= 0;

		//Lead Passengers Details
		self::$AirBookingOrder->name 			= self::$AirBookingOrder->AirPassengers[0]->firstname . ' ' . self::$AirBookingOrder->AirPassengers[0]->lastname;
		self::$AirBookingOrder->cnic 			= !empty(self::$PostalInfo['cnic']) ? self::$PostalInfo['cnic'] : (isset(self::$Passengers[0]) ? self::$Passengers[0]['passport_no'] : '11111-1111111-1');
		self::$AirBookingOrder->phone_number 	= self::$PostalInfo['phone_number'];
		self::$AirBookingOrder->address 		= self::$PostalInfo['address'];
		self::$AirBookingOrder->street 			= self::$PostalInfo['street'];
		self::$AirBookingOrder->city 			= self::$PostalInfo['city'];
		self::$AirBookingOrder->state 			= self::$PostalInfo['state'];
		self::$AirBookingOrder->postal_code 	= self::$PostalInfo['postal_code'];
		self::$AirBookingOrder->country 		= self::$PostalInfo['country'];
		self::$AirBookingOrder->area_code 		= self::$PostalInfo['area_code'];
		self::$AirBookingOrder->country_code 	= self::$PostalInfo['country_code'];
		self::$AirBookingOrder->location 		= self::$PostalInfo['location'];
		self::$AirBookingOrder->email 			= self::$PostalInfo['email'];

		//System's Stuff
		self::$AirBookingOrder->api_key 		= isset($_POST['api_key']) ? $_POST['api_key'] : "";
		self::$AirBookingOrder->payment  		= 'unpaid';
		self::$AirBookingOrder->enviroment 		= defined('AIR_ENVIROMENT') ? AIR_ENVIROMENT : null;
		self::$AirBookingOrder->created_at 		= date('Y-m-d H:i:s');

		try
		{
			return self::$AirBookingOrder->save();
		}
		catch(AirException $e)
		{
			throw new AirException($e->getMessage());
		}
	}

	public static function getOrderRefID()
	{
		return self::$AirBookingOrder->order_ref_id ?? null;
	}
}