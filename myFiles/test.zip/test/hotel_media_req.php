<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/">
    <soapenv:Header/>
    <soapenv:Body>
        <hot:HotelMediaLinksReq xmlns:common_v34_0="http://www.travelport.com/schema/common_v34_0" xmlns:hot="http://www.travelport.com/schema/hotel_v34_0" AuthorizedBy="user" Gallery="true" RichMedia="true" TargetBranch="P7119574" TraceId="trace">
            <com:BillingPointOfSaleInfo xmlns:com="http://www.travelport.com/schema/common_v34_0" OriginApplication="UAPI"/>
            <hot:HotelProperty HotelChain="HI" HotelCode="43163" HotelLocation="SYD" HotelTransportation="CourtesyBus" Name="HOLIDAY INN SYDNEY AIRPORT" ParticipationLevel="Lowest Public Rate" ReserveRequirement="Other" VendorLocationKey="GScTHe8GRUuW9jAfnz+p0g==">
                <hot:PropertyAddress>
                    <hot:Address>CORNER OF BOURKE ROA</hot:Address>
                </hot:PropertyAddress>
            </hot:HotelProperty>
        </hot:HotelMediaLinksReq>
    </soapenv:Body>
</soapenv:Envelope>